import { FILM_DB, SUB_RATES, ROLL_LENGTHS } from './data.js';

// ─── TETRIS ENGINE ────────────────────────────────────────────────────────────

function expandPanes(panes) {
  const out = [];
  panes.forEach((p, idx) => {
    for (let i = 0; i < p.qty; i++)
      out.push({ w: p.w, h: p.h, label: p.label || `Pane ${idx + 1}` });
  });
  return out;
}

function packRoll(pieces, rw) {
  const rem = [...pieces].sort((a, b) => b.w - a.w);
  const rows = [];

  while (rem.length > 0) {
    let usedW = 0, tall = 0;
    const row = [], skip = [];

    for (const p of rem) {
      if (usedW + p.w <= rw) {
        row.push({ ...p, rotated: false });
        usedW += p.w; tall = Math.max(tall, p.h);
      } else if (usedW + p.h <= rw) {
        row.push({ ...p, rotated: true, w: p.h, h: p.w });
        usedW += p.h; tall = Math.max(tall, p.w);
      } else {
        skip.push(p);
      }
    }
    if (!row.length) return null;
    rows.push({ pieces: row, usedW, pull: tall, rw });
    rem.length = 0;
    skip.forEach(p => rem.push(p));
  }

  const pullIn   = rows.reduce((s, r) => s + r.pull, 0);
  const pullFt   = pullIn / 12;
  const usedSqIn = rows.reduce((s, r) => s + r.pieces.reduce((a, p) => a + p.w * p.h, 0), 0);
  const totSqIn  = pullIn * rw;
  const wastePct = totSqIn > 0 ? ((totSqIn - usedSqIn) / totSqIn) * 100 : 0;

  return { rw, rows, pullIn, pullFt, sqft: totSqIn / 144, wastePct };
}

export function runTetris(panes) {
  const pieces = expandPanes(panes.filter(p => p.w > 0 && p.h > 0 && p.qty > 0));
  if (!pieces.length) return null;
  const plans = [48, 60, 72].map(rw => packRoll(pieces, rw)).filter(Boolean);
  if (!plans.length) return null;
  plans.sort((a, b) => a.sqft - b.sqft);
  return { winner: plans[0], all: plans };
}

// ─── MATERIAL COST ────────────────────────────────────────────────────────────

export function calcMatCost(pullFt, rollWidthIn, sqftPrice) {
  return pullFt * (rollWidthIn / 12) * sqftPrice;
}

export function calcOrderOptions(tetrisFt, rollWidthIn, sqftPrice) {
  const exactCost = calcMatCost(tetrisFt, rollWidthIn, sqftPrice);
  const rollFt    = ROLL_LENGTHS.find(l => l >= tetrisFt) ?? ROLL_LENGTHS[ROLL_LENGTHS.length - 1];
  const rollCost  = calcMatCost(rollFt, rollWidthIn, sqftPrice);
  const leftoFt   = rollFt - tetrisFt;
  const leftoSqft = leftoFt * (rollWidthIn / 12);
  return {
    exact: { ft: tetrisFt, cost: exactCost },
    roll:  { ft: rollFt, cost: rollCost, leftoFt, leftoSqft },
    diff:  rollCost - exactCost,
    smallJob: (tetrisFt * (rollWidthIn / 12)) < 300,
  };
}

// ─── SUB-CONTRACTOR LABOR ─────────────────────────────────────────────────────

export function calcSubLaborRate(filmName, isHighWork, isExterior) {
  const film = FILM_DB[filmName];
  if (!film) return 3.00;

  const cat = isExterior ? 'exterior' : film.subCategory;

  if (cat === 'security') {
    return SUB_RATES.security.getRate(film.milThickness || 4, isHighWork);
  }
  const rates = SUB_RATES[cat] || SUB_RATES.solar;
  return isHighWork ? rates.highWork : rates.standard;
}

export function calcSubLaborCost(sqft, filmName, isHighWork, isExterior) {
  const rate = calcSubLaborRate(filmName, isHighWork, isExterior);
  return { cost: sqft * rate, rate };
}

// ─── DAYS ON SITE ─────────────────────────────────────────────────────────────

export function calcDays(sqft, crewType) {
  const rate = crewType === 'owner' ? 250 : 400;
  return Math.ceil(sqft / rate);
}

// ─── FILM REMOVAL ADDER ───────────────────────────────────────────────────────
// $1.50/sqft for removal (industry standard — adjust as needed)
export const REMOVAL_RATE = 1.50;

// ─── CORE PRICE ENGINE ────────────────────────────────────────────────────────
// Takes all costs and returns Walk-Away and Recommended Target

export function buildPrice({
  materialCost,
  laborCost,
  removalCost,
  crewType,
  totalSqft,
  days,
}) {
  const pmFloor = crewType === 'owner' ? 700 : 500;
  const totalCost = materialCost + laborCost + removalCost;

  // Walk-Away: every cost covered + minimum acceptable profit
  const walkAway = totalCost + (days * pmFloor);

  // Recommended Target = HIGHEST of three rules
  const ruleA = walkAway * 1.30;                                    // 30% negotiation buffer
  const ruleB = totalSqft < 150 ? 0 : 1200;                        // minimum ticket (waived under 150 sqft)
  const ruleC = totalSqft * 7.50;                                   // $7.50/sqft floor

  const recommended = Math.max(ruleA, ruleB, ruleC);

  // Which rule won?
  let winningRule;
  if (recommended === ruleC)      winningRule = 'sqft-floor';
  else if (recommended === ruleB) winningRule = 'min-ticket';
  else                            winningRule = 'margin-buffer';

  // Gross profit at recommended price
  const grossProfit = recommended - totalCost;
  const profitPerDay = days > 0 ? grossProfit / days : 0;
  const marginPct = recommended > 0 ? (grossProfit / recommended) * 100 : 0;

  return {
    walkAway,
    recommended,
    winningRule,
    ruleA, ruleB, ruleC,
    grossProfit,
    profitPerDay,
    marginPct,
    pmFloor,
    totalCost,
  };
}

// ─── OVERRIDE CHECKER ─────────────────────────────────────────────────────────

export function checkOverride(overridePrice, walkAway, totalCost, days, pmFloor) {
  if (!overridePrice || overridePrice <= 0) return null;
  const gp    = overridePrice - totalCost;
  const ppd   = days > 0 ? gp / days : 0;
  const marg  = overridePrice > 0 ? (gp / overridePrice) * 100 : 0;
  const isLoss = overridePrice < walkAway;
  return { gp, ppd, marg, isLoss };
}

// ─── TINTWIZ PARSER ───────────────────────────────────────────────────────────

import { detectHighWork, matchFilmName } from './data.js';

export function parseTintWiz(text) {
  const result = {
    projectName: '',
    clientName:  '',
    phone:       '',
    email:       '',
    address:     '',
    totalSqft:   0,
    totalPanes:  0,
    rooms:       [],
    rawText:     text,
  };

  // Client name — first line or "Proposal To:"
  const nameMatch = text.match(/^(.+?)\s*\(/m) || text.match(/Proposal To:\s*(.+)/i);
  if (nameMatch) result.clientName = nameMatch[1].trim();

  // Phone
  const phoneMatch = text.match(/Phone:\s*([\d\s\-\(\)•]+)/i);
  if (phoneMatch) result.phone = phoneMatch[1].split('•')[0].trim();

  // Email
  const emailMatch = text.match(/Email:\s*(\S+@\S+)/i);
  if (emailMatch) result.email = emailMatch[1].trim();

  // Address
  const addrMatch = text.match(/Address:\s*(.+)/i);
  if (addrMatch) result.address = addrMatch[1].trim();

  // Project total sqft
  const totalMatch = text.match(/Total:\s*(\d+)\s*sqft/i);
  if (totalMatch) result.totalSqft = parseInt(totalMatch[1]);

  // Project name (commercial/residential label)
  const projMatch = text.match(/Project:\s*(.+?)(?:\s*[•·]|$)/im);
  if (projMatch) result.projectName = projMatch[1].trim();

  // ── Room parsing ──
  // Pattern: room name, then window count, then pane rows, then optional Notes
  const roomPattern = /^(.+?)\s+\d+\s+Window[s]?\s*\((\d+)\s+panes?\)([\s\S]*?)(?=\n\S.*\d+\s+Window[s]?\s*\(|\nPROJECT TOTAL|$)/gim;

  let m;
  while ((m = roomPattern.exec(text)) !== null) {
    const roomName  = m[1].trim();
    const paneCount = parseInt(m[2]);
    const roomBody  = m[3];

    // Skip if it looks like a totals line
    if (roomName.toUpperCase().includes('PROJECT TOTAL') || roomName.toUpperCase().includes('ROOM TOTAL')) continue;

    // Extract pane rows: QTY  DIMS  L.FT  SQFT — with optional film name between
    // Format: "Window [Film Name?] QTY WxH LF SQFT"
    const paneRows = [];
    const panePattern = /Window(?:\s+([\w\s]+?))?\s+(\d+)\s+(\d+)\s*x\s*(\d+)\s+([\d.]+)\s+(\d+)/gi;
    let pm;
    const bodyToSearch = roomBody || '';

    // Also try to extract film from body
    let filmRaw = null;
    const filmLineMatch = bodyToSearch.match(/(?:Window\s+)(Edge\s+\w[\w\s]*|ASWF\s+\w[\w\s]*|Huper\s+\w[\w\s]*|[\w]+\s+(?:View|Frost|Clear|Ceramic|Alloy|Silver|Bronze|Alloy|Twilight|Aurora|Daydream|Illusion|Sky|Nature|Legacy|Moonlight|Reflection|Firewall)\s*\d*)/i);
    if (filmLineMatch) filmRaw = filmLineMatch[1].trim();

    while ((pm = panePattern.exec(bodyToSearch)) !== null) {
      if (!filmRaw && pm[1]) filmRaw = pm[1].trim();
      paneRows.push({
        qty:    parseInt(pm[2]),
        w:      parseInt(pm[3]),
        h:      parseInt(pm[4]),
        lf:     parseFloat(pm[5]),
        sqft:   parseInt(pm[6]),
        label:  roomName,
      });
    }

    // If no pane rows parsed but we have pane count from header,
    // create a placeholder so the user can fill in dims
    if (paneRows.length === 0 && paneCount > 0) {
      paneRows.push({ qty: paneCount, w: 36, h: 48, lf: 0, sqft: 0, label: roomName });
    }

    // Notes
    const notesMatch = bodyToSearch.match(/Notes?:\s*(.+)/i);
    const notes = notesMatch ? notesMatch[1].trim() : '';

    // Removal detection
    const hasRemoval = /remov/i.test(bodyToSearch);

    // High work auto-detection from notes
    const highWorkDetected = detectHighWork(notes);

    // Film matching
    const matchedFilm = filmRaw ? matchFilmName(filmRaw) : null;

    // Room sqft from ROOM TOTAL line
    const roomTotalMatch = bodyToSearch.match(/ROOM\s+TOTAL\s+\d+\s+([\d.]+)\s+(\d+)/i);
    const roomSqft = roomTotalMatch ? parseInt(roomTotalMatch[2]) : paneRows.reduce((s, p) => s + p.sqft, 0);

    result.rooms.push({
      id:           roomName.replace(/\s+/g, '-').toLowerCase() + '-' + Math.random().toString(36).slice(2,6),
      name:         roomName,
      paneCount,
      panes:        paneRows,
      sqft:         roomSqft,
      film:         matchedFilm,
      filmRaw:      filmRaw || '',
      notes,
      hasRemoval,
      highWork:     highWorkDetected,
      isExterior:   false,
      active:       true,
    });
  }

  result.totalPanes = result.rooms.reduce((s, r) => s + r.paneCount, 0);
  if (!result.totalSqft)
    result.totalSqft = result.rooms.reduce((s, r) => s + r.sqft, 0);

  return result;
}
