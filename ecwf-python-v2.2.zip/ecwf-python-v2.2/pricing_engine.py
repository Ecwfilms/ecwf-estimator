# pricing_engine.py
# East Coast Window Films — Pricing Engine v2.2
# Handles roll optimization, material cost, Quote Builder, and sub-contractor labor.

from typing import Any, Dict, List, Optional, Tuple

# =============================================================================
# FILM RATE DATABASE
# Structure per film:
#   "Film Name": {
#       roll_width_inches: {
#           "btf_base":   base rate per LF (by-the-foot, before processing fee)
#           "btf_fee":    processing fee per LF (by-the-foot only)
#           "roll_100lf": price for a full 100 LF roll (None if unavailable)
#       }
#   }
# Source: Edge Dealer Store + Huper Optik Dealer Store, verified Mar 2026
# =============================================================================

FILM_RATES: Dict[str, Dict[int, Dict[str, float]]] = {

    # ── EDGE UltraView (Dual Reflective Architectural) ──────────────────────
    "UltraView 5": {
        48: {"btf_base": 5.87, "btf_fee": 0.505, "roll_100lf": 386.73},
        60: {"btf_base": 6.88, "btf_fee": 0.505, "roll_100lf": 550.11},
        72: {"btf_base": 7.50, "btf_fee": 0.505, "roll_100lf": 550.11},
    },
    "UltraView 15": {
        48: {"btf_base": 5.87, "btf_fee": 0.505, "roll_100lf": 386.73},
        60: {"btf_base": 6.88, "btf_fee": 0.505, "roll_100lf": 550.11},
        72: {"btf_base": 7.50, "btf_fee": 0.505, "roll_100lf": 550.11},
    },
    "UltraView 20": {
        48: {"btf_base": 5.87, "btf_fee": 0.505, "roll_100lf": 386.73},
        60: {"btf_base": 6.88, "btf_fee": 0.505, "roll_100lf": 550.11},
        72: {"btf_base": 7.50, "btf_fee": 0.505, "roll_100lf": 550.11},
    },
    "UltraView 25": {
        48: {"btf_base": 5.87, "btf_fee": 0.505, "roll_100lf": 386.73},
        60: {"btf_base": 6.88, "btf_fee": 0.505, "roll_100lf": 550.11},
        72: {"btf_base": 7.50, "btf_fee": 0.505, "roll_100lf": 550.11},
    },
    "UltraView 35": {
        48: {"btf_base": 5.87, "btf_fee": 0.505, "roll_100lf": 386.73},
        60: {"btf_base": 6.88, "btf_fee": 0.505, "roll_100lf": 550.11},
        72: {"btf_base": 7.50, "btf_fee": 0.505, "roll_100lf": 550.11},
    },
    "Edge Reform": {
        48: {"btf_base": 10.82, "btf_fee": 0.505, "roll_100lf": 1082.46},
        60: {"btf_base": 12.02, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Edge Coal Alloy": {
        48: {"btf_base": 5.60, "btf_fee": 0.505, "roll_100lf": 559.76},
        60: {"btf_base": 6.28, "btf_fee": 0.505, "roll_100lf": 627.95},
        72: {"btf_base": 7.53, "btf_fee": 0.505, "roll_100lf": 752.73},
    },
    "Edge Silver": {
        48: {"btf_base": 3.81, "btf_fee": 0.505, "roll_100lf": 380.86},
        60: {"btf_base": 4.33, "btf_fee": 0.505, "roll_100lf": 432.56},
    },
    "Edge Bronze": {
        48: {"btf_base": 5.63, "btf_fee": 0.505, "roll_100lf": 563.03},
        60: {"btf_base": 6.36, "btf_fee": 0.505, "roll_100lf": 635.91},
        72: {"btf_base": 7.63, "btf_fee": 0.505, "roll_100lf": 762.86},
    },
    "Edge Pristine Ceramic": {
        48: {"btf_base": 9.36,  "btf_fee": 0.505, "roll_100lf": 935.63},
        60: {"btf_base": 11.70, "btf_fee": 0.505, "roll_100lf": 1169.55},
        72: {"btf_base": 14.63, "btf_fee": 0.505, "roll_100lf": 1463.45},
    },
    "Guardian 4mil": {
        48: {"btf_base": 4.35, "btf_fee": 0.505, "roll_100lf": 434.91},
        60: {"btf_base": 4.81, "btf_fee": 0.505, "roll_100lf": 481.17},
        72: {"btf_base": 5.80, "btf_fee": 0.505, "roll_100lf": 579.90},
    },
    "Guardian 8mil": {
        48: {"btf_base": 5.79,  "btf_fee": 0.505, "roll_100lf": 579.40},
        60: {"btf_base": 10.82, "btf_fee": 0.505, "roll_100lf": 1082.46},
        72: {"btf_base": 8.73,  "btf_fee": 0.505, "roll_100lf": 873.30},
    },
    "Guardian 12mil": {
        48: {"btf_base": 10.96, "btf_fee": 0.505, "roll_100lf": 1096.33},
        72: {"btf_base": 13.13, "btf_fee": 0.505, "roll_100lf": 1312.95},
    },
    "Frost": {
        48: {"btf_base": 3.81, "btf_fee": 0.505, "roll_100lf": 380.84},
        60: {"btf_base": 4.40, "btf_fee": 0.505, "roll_100lf": 439.60},
        72: {"btf_base": 5.28, "btf_fee": 0.505, "roll_100lf": 527.77},
    },
    "Blackout": {
        48: {"btf_base": 4.16, "btf_fee": 0.505, "roll_100lf": 416.10},
        60: {"btf_base": 4.83, "btf_fee": 0.505, "roll_100lf": 483.12},
    },
    "Whiteout": {
        48: {"btf_base": 4.58, "btf_fee": 0.505, "roll_100lf": 458.42},
        60: {"btf_base": 5.33, "btf_fee": 0.505, "roll_100lf": 533.11},
    },
    "Clear Defense 4mil": {
        48: {"btf_base": 4.35, "btf_fee": 0.505, "roll_100lf": 434.91},
        60: {"btf_base": 4.83, "btf_fee": 0.505, "roll_100lf": 483.12},
        72: {"btf_base": 5.76, "btf_fee": 0.505, "roll_100lf": 576.08},
    },
    "Clear Defense 6mil": {
        48: {"btf_base": 5.62, "btf_fee": 0.505, "roll_100lf": 561.86},
        60: {"btf_base": 6.30, "btf_fee": 0.505, "roll_100lf": 630.03},
        72: {"btf_base": 7.50, "btf_fee": 0.505, "roll_100lf": 750.03},
    },

    # ── HUPER OPTIK ──────────────────────────────────────────────────────────
    "Huper Select Drei": {
        36: {"btf_base": 22.47, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 31.71, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 36.11, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 42.93, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Select Sech": {
        36: {"btf_base": 18.87, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 26.40, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 30.12, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 35.74, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Ceramic 20": {
        36: {"btf_base": 7.23,  "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 10.10, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 11.53, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 13.56, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Ceramic 30": {
        36: {"btf_base": 7.23,  "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 10.10, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 11.53, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 13.56, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Ceramic 40": {
        36: {"btf_base": 7.23,  "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 10.10, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 11.53, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 22.05, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Ceramic 50": {
        36: {"btf_base": 7.23,  "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 10.10, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 11.53, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 13.56, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Ceramic 60": {
        36: {"btf_base": 7.23,  "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 10.10, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 11.53, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 13.56, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Ceramic 70": {
        36: {"btf_base": 7.23,  "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 10.10, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 11.53, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 13.56, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Fusion 10": {
        36: {"btf_base": 5.67, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 7.28, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 8.12, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 9.34, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Fusion 20": {
        36: {"btf_base": 5.67, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 7.28, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 8.12, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 9.34, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Fusion 28": {
        36: {"btf_base": 5.67, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 7.28, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 8.12, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 9.34, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Bronze 25": {
        36: {"btf_base": 6.65, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 8.66, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 9.74, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 11.29, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Bronze 40": {
        36: {"btf_base": 6.65, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 8.66, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 9.74, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 11.29, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Silver 18": {
        36: {"btf_base": 5.21, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 6.75, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 7.36, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 8.43, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Silver 30": {
        36: {"btf_base": 5.21, "btf_fee": 0.505, "roll_100lf": None},
        48: {"btf_base": 6.75, "btf_fee": 0.505, "roll_100lf": None},
        60: {"btf_base": 7.36, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 8.43, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper ClearShield 4mil": {
        60: {"btf_base": 9.52,  "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 10.82, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper ClearShield 8mil": {
        60: {"btf_base": 12.84, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 14.81, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper ClearShield 14mil": {
        60: {"btf_base": 17.37, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 20.24, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Huper Shield 35 Neutral 8mil": {
        60: {"btf_base": 16.51, "btf_fee": 0.505, "roll_100lf": None},
        72: {"btf_base": 19.21, "btf_fee": 0.505, "roll_100lf": None},
    },
    "Twilight 35": {
        48: {"btf_base": 8.00, "btf_fee": 0.00, "roll_100lf": None},
        60: {"btf_base": 10.00, "btf_fee": 0.00, "roll_100lf": None},
    },
    "Twilight 20": {
        48: {"btf_base": 8.00, "btf_fee": 0.00, "roll_100lf": None},
        60: {"btf_base": 10.00, "btf_fee": 0.00, "roll_100lf": None},
    },
    "Twilight 10": {
        48: {"btf_base": 8.00, "btf_fee": 0.00, "roll_100lf": None},
        60: {"btf_base": 10.00, "btf_fee": 0.00, "roll_100lf": None},
    },
}

DEFAULT_FILM_RATES = {
    48: {"btf_base": 5.87, "btf_fee": 0.505, "roll_100lf": None},
    60: {"btf_base": 6.88, "btf_fee": 0.505, "roll_100lf": None},
    72: {"btf_base": 7.50, "btf_fee": 0.505, "roll_100lf": None},
}

# =============================================================================
# SUB-CONTRACTOR RATE TABLE
# Rates per sqft of glass installed.
# Source: ECWF Sub-Contractor Pricing Guide
# =============================================================================

SUB_RATES = {
    # Solar / Architectural films
    "solar":      {"standard": 3.00, "high_work": 3.25},
    # Exterior films (same as solar)
    "exterior":   {"standard": 3.00, "high_work": 3.25},
    # Decorative films (frosts, gradients — bump manually for custom patterns)
    "decorative": {"standard": 3.00, "high_work": 3.00},
    # Security films — tiered by mil thickness
    "security": {
        "standard": {4: 3.00, 8: 3.00, 11: 3.25, 15: 3.50, 23: 4.00},
        "high_work": {4: 3.25, 8: 3.25, 11: 3.50, 15: 3.75, 23: 4.25},
    },
}

# Maps film name keywords → sub rate category
FILM_SUB_CATEGORY = {
    "ultraview":       "solar",
    "twilight":        "solar",
    "coal alloy":      "solar",
    "silver":          "solar",
    "bronze":          "solar",
    "pristine":        "solar",
    "reform":          "solar",
    "huper":           "solar",
    "frost":           "decorative",
    "blackout":        "decorative",
    "whiteout":        "decorative",
    "guardian":        "security",
    "clearshield":     "security",
    "clear defense":   "security",
}

# Mil thickness lookup for security films (for sub rate tiering)
SECURITY_MIL = {
    "guardian 4mil": 4,  "guardian 8mil": 8,  "guardian 12mil": 12,
    "clearshield 4mil": 4, "clearshield 8mil": 8, "clearshield 14mil": 14,
    "clear defense 4mil": 4, "clear defense 6mil": 6,
}

# Film removal adder
REMOVAL_RATE_PER_SQFT = 1.50

# Production rates (sqft per day)
OWNER_SQFT_PER_DAY = 250
SUB_SQFT_PER_DAY   = 400
SOLO_INSTALLER_SQFT_PER_DAY = OWNER_SQFT_PER_DAY  # kept for backward compat

# High-work keyword detector
HIGH_WORK_KEYWORDS = [
    "lift", "ladder", "scaffold", "aff", "above finished",
    "high work", "exterior", "12 ft", "12ft", "elevated",
    "boom", "scissor", "manlift"
]


def detect_high_work(notes_text: str) -> bool:
    if not notes_text:
        return False
    lower = notes_text.lower()
    return any(kw in lower for kw in HIGH_WORK_KEYWORDS)


def get_sub_category(film_name: str, is_exterior: bool = False) -> str:
    if is_exterior:
        return "exterior"
    lower = film_name.lower()
    for kw, cat in FILM_SUB_CATEGORY.items():
        if kw in lower:
            return cat
    return "solar"


def get_sub_labor_rate(film_name: str, is_high_work: bool, is_exterior: bool = False) -> float:
    """Return the sub-contractor rate per sqft for a given film and conditions."""
    cat = get_sub_category(film_name, is_exterior)

    if cat == "security":
        film_lower = film_name.lower()
        mil = 4
        for key, m in SECURITY_MIL.items():
            if key in film_lower:
                mil = m
                break
        tier_key = "high_work" if is_high_work else "standard"
        tier = SUB_RATES["security"][tier_key]
        # Find the right mil bracket
        for threshold in sorted(tier.keys(), reverse=True):
            if mil >= threshold:
                return tier[threshold]
        return 3.00

    rates = SUB_RATES.get(cat, SUB_RATES["solar"])
    return rates["high_work"] if is_high_work else rates["standard"]


def calculate_sub_labor(sqft: float, film_name: str,
                        is_high_work: bool, is_exterior: bool = False) -> Dict[str, float]:
    rate = get_sub_labor_rate(film_name, is_high_work, is_exterior)
    return {"cost": round(sqft * rate, 2), "rate": rate}


# =============================================================================
# FILM RATES LOOKUP
# =============================================================================

def get_film_rates(film_name: str, roll_width: int) -> Dict[str, float]:
    rates = FILM_RATES.get(film_name, {})
    if roll_width in rates:
        return rates[roll_width]
    film_lower = film_name.lower()
    for key, widths in FILM_RATES.items():
        if key.lower() in film_lower or film_lower in key.lower():
            if roll_width in widths:
                return widths[roll_width]
    return DEFAULT_FILM_RATES.get(roll_width, DEFAULT_FILM_RATES[48])


def get_price_floor(film_name: str) -> float:
    """Minimum selling price per sqft for the given film family (used as Rule C baseline)."""
    PRICE_FLOORS: Dict[str, float] = {
        "UltraView":      7.50,
        "Twilight":      10.00,
        "Aurora":        12.00,
        "Huper":         12.00,
        "Edge Pristine": 12.00,
        "Safety":         8.00,
        "Guardian":       8.00,
        "Decorative":     6.00,
        "default":        7.50,
    }
    for family, floor in PRICE_FLOORS.items():
        if family.lower() in film_name.lower():
            return floor
    return PRICE_FLOORS["default"]


# =============================================================================
# MATERIAL COST
# =============================================================================

def calculate_material_cost(film_name: str, roll_width: int,
                             required_lf: float, buffer_lf: float) -> Dict[str, Any]:
    rates = get_film_rates(film_name, roll_width)
    order_lf = required_lf + buffer_lf
    order_lf_ceil = int(order_lf) + (1 if order_lf % 1 > 0 else 0)

    btf_cost = round(order_lf_ceil * (rates["btf_base"] + rates["btf_fee"]), 2)

    full_roll_cost = None
    full_roll_savings = None
    order_method = "by_the_foot"
    recommended_cost = btf_cost

    if rates.get("roll_100lf") and order_lf_ceil <= 100:
        full_roll_cost = rates["roll_100lf"]
        if full_roll_cost < btf_cost:
            full_roll_savings = round(btf_cost - full_roll_cost, 2)
            recommended_cost = full_roll_cost
            order_method = "full_roll"
            order_lf_ceil = 100

    return {
        "order_lf": order_lf_ceil,
        "btf_cost": btf_cost,
        "full_roll_cost": full_roll_cost,
        "full_roll_savings": full_roll_savings,
        "recommended_cost": recommended_cost,
        "order_method": order_method,
        "rates": rates,
    }


# =============================================================================
# QUOTE BUILDER — WALK-AWAY + RECOMMENDED TARGET
# =============================================================================

def calculate_days(total_sqft: float, crew_type: str) -> float:
    """Estimate days on site. Returns fractional days, ceiling applied where needed."""
    import math
    rate = OWNER_SQFT_PER_DAY if crew_type == "owner" else SUB_SQFT_PER_DAY
    return math.ceil(total_sqft / rate) if total_sqft > 0 else 1


def build_quote(
    material_cost: float,
    labor_cost: float,
    removal_cost: float,
    total_sqft: float,
    crew_type: str,
) -> Dict[str, Any]:
    """
    Core Quote Builder engine.

    Walk-Away Price = all costs + (days × PM profit floor)
    Recommended Price = HIGHEST of three rules:
      A) Walk-Away × 1.30  (30% negotiation buffer)
      B) $1,200 flat minimum  (waived if sqft < 150)
      C) $7.50/sqft floor

    Returns full breakdown for UI display.
    """
    pm_floor = 700.0 if crew_type == "owner" else 500.0
    days = calculate_days(total_sqft, crew_type)
    total_cost = material_cost + labor_cost + removal_cost

    walk_away = round(total_cost + (days * pm_floor), 2)

    rule_a = round(walk_away * 1.30, 2)
    rule_b = 0.0 if total_sqft < 150 else 1200.0
    rule_c = round(total_sqft * 7.50, 2)

    recommended = max(rule_a, rule_b, rule_c)

    if recommended == rule_c:
        winning_rule = "sqft_floor"
        winning_label = "$7.50/sqft Floor"
    elif recommended == rule_b:
        winning_rule = "min_ticket"
        winning_label = "$1,200 Minimum Ticket"
    else:
        winning_rule = "margin_buffer"
        winning_label = "30% Negotiation Buffer"

    gross_profit = round(recommended - total_cost, 2)
    profit_per_day = round(gross_profit / days, 2) if days > 0 else 0.0
    margin_pct = round((gross_profit / recommended) * 100, 1) if recommended > 0 else 0.0

    return {
        "walk_away":     walk_away,
        "recommended":   recommended,
        "winning_rule":  winning_rule,
        "winning_label": winning_label,
        "rule_a":        rule_a,
        "rule_b":        rule_b,
        "rule_c":        rule_c,
        "gross_profit":  gross_profit,
        "profit_per_day": profit_per_day,
        "margin_pct":    margin_pct,
        "pm_floor":      pm_floor,
        "total_cost":    total_cost,
        "days":          days,
        "material_cost": material_cost,
        "labor_cost":    labor_cost,
        "removal_cost":  removal_cost,
    }


def check_override(override_price: float, quote: Dict[str, Any]) -> Dict[str, Any]:
    """Evaluate a manually entered price against the Walk-Away floor."""
    total_cost = quote["total_cost"]
    days = quote["days"]
    pm_floor = quote["pm_floor"]

    gp   = round(override_price - total_cost, 2)
    ppd  = round(gp / days, 2) if days > 0 else 0.0
    marg = round((gp / override_price) * 100, 1) if override_price > 0 else 0.0
    is_loss = override_price < quote["walk_away"]

    return {
        "price":   override_price,
        "gp":      gp,
        "ppd":     ppd,
        "marg":    marg,
        "is_loss": is_loss,
    }


# =============================================================================
# OPTIMIZATION ENGINE (unchanged from v1)
# First-Fit Decreasing bin-packing with pane rotation support.
# =============================================================================

def _orientation_options(pane, roll_width):
    width = int(pane["width"])
    height = int(pane["height"])
    options = []
    if width <= roll_width:
        options.append({"width": width, "height": height})
    if height <= roll_width and height != width:
        options.append({"width": height, "height": width})
    return options


def _pane_sort_key(pane, roll_width):
    width = int(pane["width"])
    height = int(pane["height"])
    return (max(width, height), min(width, height), width * height)


def _best_fit_for_existing_row(pane, row, roll_width):
    remaining_width = roll_width - row["used_width"]
    current_pull_to = row["pull_to"]
    best_option = None
    best_score = None

    for option in _orientation_options(pane, roll_width):
        if option["width"] > remaining_width:
            continue
        added_pull = max(current_pull_to, option["height"]) - current_pull_to
        score = (added_pull, -(row["used_width"] + option["width"]))
        if best_score is None or score < best_score:
            best_score = score
            best_option = option
    return best_option


def _best_fit_for_new_row(pane, roll_width):
    best_option = None
    best_score = None
    for option in _orientation_options(pane, roll_width):
        score = (option["height"], -option["width"])
        if best_score is None or score < best_score:
            best_score = score
            best_option = option
    return best_option


def optimize_for_roll_width(panes: List[Dict[str, Any]], roll_width: int) -> Dict[str, Any]:
    """
    Arrange panes across a single roll width using First-Fit Decreasing heuristic.
    Returns total_lf and row layout details.
    """
    if roll_width <= 0:
        raise ValueError("roll_width must be a positive integer")
    if not panes:
        return {"total_lf": 0.0, "rows": []}

    sorted_panes = sorted(
        [{"width": int(p["width"]), "height": int(p["height"])} for p in panes],
        key=lambda p: _pane_sort_key(p, roll_width),
        reverse=True,
    )

    rows: List[Dict[str, Any]] = []

    for pane in sorted_panes:
        placed = False
        for row in rows:
            option = _best_fit_for_existing_row(pane, row, roll_width)
            if option is None:
                continue
            row["panes"].append(option)
            row["used_width"] += option["width"]
            row["pull_to"] = max(row["pull_to"], option["height"])
            row["lanes"] = len(row["panes"])
            placed = True
            break

        if not placed:
            option = _best_fit_for_new_row(pane, roll_width)
            if option is None:
                raise ValueError(
                    f"Pane {pane} cannot fit on roll width {roll_width} in any orientation."
                )
            rows.append({
                "panes": [option],
                "used_width": option["width"],
                "pull_to": option["height"],
                "lanes": 1,
            })

    total_inches = sum(row["pull_to"] for row in rows)
    total_lf = round(total_inches / 12.0, 2)

    return {"total_lf": total_lf, "rows": rows}


def group_windows_by_section(windows: List[Dict]) -> Dict[str, List[Dict]]:
    groups: Dict[str, List[Dict]] = {}
    for w in windows:
        section = w.get("section", "Unassigned")
        if section not in groups:
            groups[section] = []
        groups[section].append(w)
    return groups
