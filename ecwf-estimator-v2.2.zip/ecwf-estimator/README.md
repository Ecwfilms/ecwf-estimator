# ECWF Estimator Engine — Deployment Guide
Version 2.2 | East Coast Window Films

---

## How to Deploy to Vercel (Step by Step)

### Step 1 — Create your Vercel account
Go to https://vercel.com and sign up for free.

### Step 2 — Deploy the project
1. On the Vercel dashboard, click **"Add New Project"**
2. Choose **"Deploy without Git"** (drag and drop option)
3. Drag the entire `ecwf-estimator` folder into the upload area

### Step 3 — Confirm Build Settings
When Vercel shows the build configuration screen, verify these exact values:

| Setting            | Value         |
|--------------------|---------------|
| Framework Preset   | Vite          |
| Build Command      | npm run build |
| Output Directory   | dist          |
| Install Command    | npm install   |

Click **Deploy**. Build takes about 60 seconds.

### Step 4 — Add your custom domain
1. In your Vercel project, go to **Settings → Domains**
2. Type in: `estimator.ecwfilms.com`
3. Click Add

### Step 5 — Add DNS record in GoDaddy
1. Log into GoDaddy → My Products → DNS → Manage Zones → ecwfilms.com
2. Add a new record:

| Field         | Value                  |
|---------------|------------------------|
| Record Type   | CNAME                  |
| Host / Name   | estimator              |
| Points To     | cname.vercel-dns.com   |
| TTL           | 600 (1 Hour)           |

3. Delete any existing A record or CNAME for "estimator" if one exists

### Step 6 — Wait for green checkmark
DNS propagates in 5–30 minutes. Once Vercel shows a green checkmark
next to your domain, the app is live at estimator.ecwfilms.com

---

## Updating the App in the Future

Option A (drag and drop): Rebuild the folder, drag into Vercel again.
Option B (recommended): Connect to a GitHub repo — every push auto-deploys.

---

## Project File Structure

```
ecwf-estimator/
├── index.html          ← Entry point (do not edit)
├── package.json        ← Dependencies (do not edit)
├── vite.config.js      ← Build config (do not edit)
└── src/
    ├── main.jsx        ← React mount (do not edit)
    ├── data.js         ← Film DB + sub rates + pricing constants
    ├── engine.js       ← Tetris engine + ECWF formulas + TintWiz parser
    └── App.jsx         ← Full UI — edit this for layout/feature changes
```

## Where to Make Changes

- **Add a new film product** → `src/data.js` → FILM_DB object
- **Change sub-contractor rates** → `src/data.js` → SUB_RATES object
- **Change removal rate** → `src/engine.js` → REMOVAL_RATE constant
- **Change profit floors** → `src/engine.js` → buildPrice() function
- **Change the $7.50/sqft floor or 30% buffer** → `src/engine.js` → buildPrice()
- **UI layout changes** → `src/App.jsx`

---

## What the Tool Does (Plain English)

1. You paste a TintWiz worksheet → it extracts client, rooms, pane dims, film, and notes
2. Notes are scanned for lift/ladder/AFF keywords → High Work flag auto-checks
3. Tetris engine runs per room → finds the most efficient roll width and pull length
4. Material cost = actual linear feet pulled × roll width × dealer film price
5. Sub labor cost = sqft × sub rate (auto-mapped from film type, adjusted for high work)
6. Walk-Away Price = all costs + (days × profit floor)
7. Recommended Price = highest of: Walk-Away×1.30, $1,200 minimum, sqft×$7.50
8. Room checkboxes re-run the full Tetris engine on remaining active rooms
9. Override price field shows live margin, profit/day, and a red LOSS warning if below walk-away
