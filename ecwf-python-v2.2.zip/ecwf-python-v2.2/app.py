# app.py
# East Coast Window Films — Internal Estimator v2.2
# Quote Builder: Walk-Away Price + Recommended Target + Sub-Contractor Labor

import streamlit as st
from worksheet_parser import extract_text_from_pdf, extract_window_data
from pricing_engine import (
    optimize_for_roll_width,
    group_windows_by_section,
    calculate_material_cost,
    calculate_sub_labor,
    calculate_days,
    build_quote,
    check_override,
    detect_high_work,
    REMOVAL_RATE_PER_SQFT,
    OWNER_SQFT_PER_DAY,
    SUB_SQFT_PER_DAY,
)
from pane_expander import expand_windows

# ─────────────────────────────────────────────────────────────────────────────
# Page Config
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="ECWF Estimator",
    page_icon="🪟",
    layout="wide"
)

# ─────────────────────────────────────────────────────────────────────────────
# Custom CSS
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .ribbon {
        background: linear-gradient(135deg, #0d1f35 0%, #091628 100%);
        border: 1px solid #2e4870;
        border-radius: 8px;
        padding: 16px 20px;
        margin-bottom: 20px;
    }
    .ribbon-project {
        font-size: 11px;
        color: #00e5a0;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        margin-bottom: 2px;
    }
    .ribbon-name {
        font-size: 20px;
        font-weight: 700;
        color: #e8f0fe;
        margin-bottom: 12px;
    }
    .walk-away-box {
        background: rgba(255,179,0,0.08);
        border: 1px solid rgba(255,179,0,0.4);
        border-radius: 6px;
        padding: 10px 14px;
        margin: 8px 0;
    }
    .target-box {
        background: rgba(0,229,160,0.08);
        border: 1px solid rgba(0,229,160,0.4);
        border-radius: 6px;
        padding: 10px 14px;
        margin: 8px 0;
    }
    .loss-box {
        background: rgba(255,68,85,0.12);
        border: 2px solid #ff4455;
        border-radius: 6px;
        padding: 10px 14px;
        margin: 8px 0;
    }
    .rule-winner {
        background: rgba(0,229,160,0.10);
        border: 1px solid rgba(0,229,160,0.3);
        border-radius: 4px;
        padding: 6px 10px;
        margin: 3px 0;
    }
    .rule-normal {
        background: transparent;
        padding: 6px 10px;
        margin: 3px 0;
        color: #8899aa;
    }
    .section-card {
        background: #0d1f35;
        border: 1px solid #1e3050;
        border-radius: 6px;
        padding: 14px 16px;
        margin-bottom: 12px;
    }
    .high-work-badge {
        background: rgba(255,179,0,0.15);
        color: #ffb300;
        border-radius: 3px;
        padding: 2px 8px;
        font-size: 11px;
        font-weight: 700;
    }
    .removal-badge {
        background: rgba(167,139,250,0.15);
        color: #a78bfa;
        border-radius: 3px;
        padding: 2px 8px;
        font-size: 11px;
        font-weight: 700;
    }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("## 🪟 East Coast Window Films — Estimator")
st.caption("Internal use only. Upload a TintWiz worksheet PDF to begin.")

# ─────────────────────────────────────────────────────────────────────────────
# Sidebar: Crew Settings
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Job Settings")

    crew_type = st.radio(
        "Installation Type",
        options=["owner", "sub"],
        format_func=lambda x: "👤 Owner Install" if x == "owner" else "👷 Sub-Contractor",
        help="Owner install: $700/day PM floor. Sub-contractor: $500/day PM floor after paying sub."
    )

    buffer_lf = st.number_input(
        "Installer Buffer (LF)",
        min_value=0.0, value=10.0, step=5.0,
        help="Extra linear feet added to material order as a safety buffer."
    )

    st.divider()
    st.caption(
        f"**{'Owner' if crew_type == 'owner' else 'Sub-Contractor'} mode active.**\n\n"
        f"PM Profit Floor: **${'700' if crew_type == 'owner' else '500'}/day**\n\n"
        f"Production rate: **{OWNER_SQFT_PER_DAY if crew_type == 'owner' else SUB_SQFT_PER_DAY} sqft/day**"
    )
    st.divider()
    st.caption("Film costs loaded from Edge, Huper Optik, and ASWF. Verified Mar 2026.")

# ─────────────────────────────────────────────────────────────────────────────
# File Upload
# ─────────────────────────────────────────────────────────────────────────────
uploaded_file = st.file_uploader(
    "Upload TintWiz Worksheet",
    type=["pdf"],
    accept_multiple_files=False,
    help="Export the worksheet from TintWiz as a PDF and upload it here."
)

if not uploaded_file:
    st.info("Upload a TintWiz worksheet PDF to begin.")
    st.stop()

# ─────────────────────────────────────────────────────────────────────────────
# Parse PDF
# ─────────────────────────────────────────────────────────────────────────────
text   = extract_text_from_pdf(uploaded_file)
parsed = extract_window_data(text)

windows             = parsed["windows"]
section_meta        = parsed["section_meta"]
project_total_sqft  = parsed["project_total_sqft"] or 0
project_total_panes = parsed["project_total_panes"] or 0
client_info         = parsed.get("client_info", {})

if not windows:
    st.error("No window data found. Check the PDF format.")
    st.stop()

section_groups = group_windows_by_section(windows)

# ─────────────────────────────────────────────────────────────────────────────
# Per-Section State (room toggles + flags)
# Uses st.session_state so toggles survive reruns without full recalc
# ─────────────────────────────────────────────────────────────────────────────
for sec_name in section_groups:
    meta = section_meta.get(sec_name, {})

    # Initialize state keys once
    active_key   = f"active_{sec_name}"
    hw_key       = f"hw_{sec_name}"
    rem_key      = f"rem_{sec_name}"
    ext_key      = f"ext_{sec_name}"

    if active_key not in st.session_state:
        st.session_state[active_key] = True
    if hw_key not in st.session_state:
        st.session_state[hw_key] = meta.get("high_work", False)
    if rem_key not in st.session_state:
        st.session_state[rem_key] = meta.get("has_removal", False)
    if ext_key not in st.session_state:
        st.session_state[ext_key] = meta.get("is_exterior", False)

# ─────────────────────────────────────────────────────────────────────────────
# Build per-section results (only active sections)
# ─────────────────────────────────────────────────────────────────────────────
section_results = {}
total_mat_cost    = 0.0
total_labor_cost  = 0.0
total_removal_cost = 0.0
total_active_sqft = 0.0

for section_name, section_windows in section_groups.items():
    if not st.session_state.get(f"active_{section_name}", True):
        continue

    section_panes = expand_windows(section_windows)
    film_names    = sorted(set(w["film"] for w in section_windows))
    primary_film  = film_names[0] if film_names else "UltraView 15"
    section_sqft  = section_meta.get(section_name, {}).get("room_total_sqft", 0) or 0

    is_high_work = st.session_state.get(f"hw_{section_name}", False)
    has_removal  = st.session_state.get(f"rem_{section_name}", False)
    is_exterior  = st.session_state.get(f"ext_{section_name}", False)

    # Roll optimization
    roll_options = [48, 60, 72]
    comparison   = []
    for roll in roll_options:
        try:
            opt  = optimize_for_roll_width(section_panes, roll)
            cost = calculate_material_cost(primary_film, roll, opt["total_lf"], buffer_lf)
            comparison.append({
                "roll": roll, "required_lf": opt["total_lf"],
                "order_lf": cost["order_lf"], "mat_cost": cost["recommended_cost"],
                "btf_cost": cost["btf_cost"], "full_roll_cost": cost["full_roll_cost"],
                "full_roll_savings": cost["full_roll_savings"],
                "order_method": cost["order_method"], "rates": cost["rates"],
                "rows": opt["rows"],
            })
        except ValueError:
            pass

    if not comparison:
        continue

    best = min(comparison, key=lambda x: x["mat_cost"])

    # Sub labor
    if crew_type == "sub":
        sub_result   = calculate_sub_labor(section_sqft, primary_film, is_high_work, is_exterior)
        section_labor = sub_result["cost"]
        sub_rate      = sub_result["rate"]
    else:
        section_labor = 0.0
        sub_rate      = 0.0

    # Removal adder
    removal_cost = (section_sqft * REMOVAL_RATE_PER_SQFT) if has_removal else 0.0

    total_mat_cost     += best["mat_cost"]
    total_labor_cost   += section_labor
    total_removal_cost += removal_cost
    total_active_sqft  += section_sqft

    section_results[section_name] = {
        "best": best, "comparison": comparison,
        "film_names": film_names, "primary_film": primary_film,
        "section_sqft": section_sqft,
        "section_labor": section_labor, "sub_rate": sub_rate,
        "removal_cost": removal_cost,
        "is_high_work": is_high_work, "has_removal": has_removal, "is_exterior": is_exterior,
        "notes": section_meta.get(section_name, {}).get("notes", ""),
    }

# ─────────────────────────────────────────────────────────────────────────────
# Job-level Quote Builder
# ─────────────────────────────────────────────────────────────────────────────
quote = build_quote(
    material_cost  = total_mat_cost,
    labor_cost     = total_labor_cost,
    removal_cost   = total_removal_cost,
    total_sqft     = total_active_sqft,
    crew_type      = crew_type,
)

# Override input (sidebar bottom)
with st.sidebar:
    st.divider()
    st.subheader("💬 Negotiation Override")
    override_input = st.number_input(
        "Client Offer / Your Override ($)",
        min_value=0.0, value=0.0, step=50.0,
        help="Enter a price to see how it compares to your Walk-Away floor."
    )
    if override_input > 0:
        ovr = check_override(override_input, quote)
        if ovr["is_loss"]:
            st.error(f"⛔ LOSS — ${override_input:,.2f} is below your Walk-Away of ${quote['walk_away']:,.2f}")
        else:
            st.success(f"✅ Override margin: {ovr['marg']}% · ${ovr['ppd']:,.2f}/day")
        st.caption(f"Override gross profit: ${ovr['gp']:,.2f}")
    else:
        ovr = None

# ─────────────────────────────────────────────────────────────────────────────
# SUMMARY RIBBON — Always first
# ─────────────────────────────────────────────────────────────────────────────
client_name  = client_info.get("client_name", uploaded_file.name.replace(".pdf", ""))
project_type = client_info.get("project_type", "")
display_name = f"{client_name}" + (f" — {project_type}" if project_type else "")

display_price = ovr["price"] if ovr and not ovr["is_loss"] else quote["recommended"]
price_label   = "OVERRIDE PRICE" if (ovr and not ovr["is_loss"]) else "RECOMMENDED SELL PRICE"
price_color   = "#ff4455" if (ovr and ovr["is_loss"]) else "#00e5a0"

st.markdown(f"""
<div class="ribbon">
  <div class="ribbon-project">PROJECT</div>
  <div class="ribbon-name">{display_name}</div>
  <div style="display:grid; grid-template-columns: repeat(5, 1fr); gap: 12px;">
    <div>
      <div style="font-size:10px; color:#8899aa; text-transform:uppercase; letter-spacing:0.1em;">Total SqFt</div>
      <div style="font-size:18px; font-weight:700; color:#e8f0fe;">{total_active_sqft:.0f} sqft</div>
    </div>
    <div>
      <div style="font-size:10px; color:#8899aa; text-transform:uppercase; letter-spacing:0.1em;">Material Cost</div>
      <div style="font-size:18px; font-weight:700; color:#e8f0fe;">${total_mat_cost:,.2f}</div>
    </div>
    <div>
      <div style="font-size:10px; color:#8899aa; text-transform:uppercase; letter-spacing:0.1em;">{'Sub Labor' if crew_type == 'sub' else 'Owner Labor'}</div>
      <div style="font-size:18px; font-weight:700; color:#e8f0fe;">${total_labor_cost:,.2f}</div>
    </div>
    <div>
      <div style="font-size:10px; color:#ffb300; text-transform:uppercase; letter-spacing:0.1em;">Walk-Away Floor</div>
      <div style="font-size:18px; font-weight:700; color:#ffb300;">${quote['walk_away']:,.2f}</div>
    </div>
    <div>
      <div style="font-size:10px; color:{price_color}; text-transform:uppercase; letter-spacing:0.1em;">{price_label}</div>
      <div style="font-size:22px; font-weight:700; color:{price_color};">${display_price:,.2f}</div>
    </div>
  </div>
</div>
""", unsafe_allow_html=True)

# Loss warning if override is active and below walk-away
if ovr and ovr["is_loss"]:
    st.error(
        f"⛔ **OVERRIDE ${override_input:,.2f} IS BELOW WALK-AWAY ${quote['walk_away']:,.2f} — THIS IS A LOSS.** "
        f"Gross profit would be **${ovr['gp']:,.2f}** (${ovr['ppd']:,.2f}/day vs your ${quote['pm_floor']:.0f}/day floor)."
    )

# ─────────────────────────────────────────────────────────────────────────────
# Quote Builder Panel
# ─────────────────────────────────────────────────────────────────────────────
with st.expander("💰 Quote Builder — Price Logic", expanded=True):
    col_rules, col_numbers = st.columns([1.2, 1])

    with col_rules:
        st.markdown("**How the Recommended Price was set:**")

        rules = [
            ("A) 30% Negotiation Buffer", quote["rule_a"], "margin_buffer"),
            ("B) $1,200 Minimum Ticket",  quote["rule_b"], "min_ticket"),
            ("C) $7.50/sqft Floor",        quote["rule_c"], "sqft_floor"),
        ]
        for label, val, key in rules:
            is_winner = quote["winning_rule"] == key
            css_class = "rule-winner" if is_winner else "rule-normal"
            arrow = " ← **WINNER**" if is_winner else ""
            st.markdown(
                f'<div class="{css_class}">'
                f'{"✅ " if is_winner else ""}{label}: **${val:,.2f}**{arrow}'
                f'</div>',
                unsafe_allow_html=True
            )

        st.markdown("---")
        st.markdown(
            f'<div class="walk-away-box">'
            f'**Walk-Away Floor: ${quote["walk_away"]:,.2f}**<br>'
            f'<small>Total Cost ${quote["total_cost"]:,.2f} + '
            f'{quote["days"]} day(s) × ${quote["pm_floor"]:.0f}/day PM floor</small>'
            f'</div>',
            unsafe_allow_html=True
        )
        st.markdown(
            f'<div class="target-box">'
            f'**Recommended: ${quote["recommended"]:,.2f}** — {quote["winning_label"]}'
            f'</div>',
            unsafe_allow_html=True
        )

    with col_numbers:
        st.metric("Gross Profit",    f"${quote['gross_profit']:,.2f}")
        st.metric("Margin %",        f"{quote['margin_pct']}%")
        st.metric("Profit / Day",    f"${quote['profit_per_day']:,.2f}",
                  delta=f"floor: ${quote['pm_floor']:.0f}/day",
                  delta_color="normal")
        st.metric("Days on Site",    f"{quote['days']} day(s)")
        st.caption(
            f"**Cost audit:** Material ${quote['material_cost']:,.2f} · "
            f"Labor ${quote['labor_cost']:,.2f} · "
            f"Removal ${quote['removal_cost']:,.2f} · "
            f"Total cost ${quote['total_cost']:,.2f}"
        )

st.divider()

# ─────────────────────────────────────────────────────────────────────────────
# Client Info
# ─────────────────────────────────────────────────────────────────────────────
if client_info:
    with st.expander("👤 Client Info", expanded=False):
        cols = st.columns(3)
        if "phone" in client_info:   cols[0].markdown(f"📞 {client_info['phone']}")
        if "email" in client_info:   cols[1].markdown(f"✉️ {client_info['email']}")
        if "address" in client_info: cols[2].markdown(f"📍 {client_info['address']}")

# ─────────────────────────────────────────────────────────────────────────────
# Project Summary
# ─────────────────────────────────────────────────────────────────────────────
st.subheader("📋 Project Summary")
c1, c2, c3 = st.columns(3)
c1.metric("Active Square Footage", f"{total_active_sqft:.0f} sqft")
c2.metric("Total Pane Count",      f"{project_total_panes} panes")
c3.metric("Active Sections",       f"{len(section_results)} of {len(section_groups)}")
st.divider()

# ─────────────────────────────────────────────────────────────────────────────
# Room Breakdown — with checkboxes and flags
# ─────────────────────────────────────────────────────────────────────────────
st.subheader("🏠 Room Breakdown")
st.caption("Toggle rooms on/off — Tetris re-runs automatically on remaining active rooms.")

order_lines = []

for section_name, section_windows in section_groups.items():
    meta = section_meta.get(section_name, {})

    # ── Room header with checkbox ──────────────────────────────────────────
    header_cols = st.columns([0.05, 0.95])
    with header_cols[0]:
        active = st.checkbox(
            "", value=st.session_state.get(f"active_{section_name}", True),
            key=f"cb_active_{section_name}",
            label_visibility="collapsed"
        )
        st.session_state[f"active_{section_name}"] = active

    with header_cols[1]:
        section_sqft_display = meta.get("room_total_sqft", 0) or 0
        panes_display = meta.get("section_panes_header", 0)
        status = "" if active else " *(excluded)*"

        badges = ""
        if st.session_state.get(f"hw_{section_name}"):
            badges += ' <span class="high-work-badge">⚠ HIGH WORK</span>'
        if st.session_state.get(f"rem_{section_name}"):
            badges += ' <span class="removal-badge">🔧 REMOVAL</span>'

        st.markdown(
            f"**{section_name}**{status} — {panes_display} panes · {section_sqft_display} sqft {badges}",
            unsafe_allow_html=True
        )

    if not active:
        st.divider()
        continue

    res = section_results.get(section_name)
    if not res:
        st.warning(f"No valid roll width found for '{section_name}'. Check pane dimensions.")
        st.divider()
        continue

    best = res["best"]

    # ── Notes ──────────────────────────────────────────────────────────────
    if res["notes"]:
        st.info(f"📋 **Notes:** {res['notes']}")

    # ── Complexity flags ───────────────────────────────────────────────────
    flag_cols = st.columns(3)
    with flag_cols[0]:
        hw = st.checkbox(
            "⚠ High Work / Lift (12–25 ft AFF)",
            value=st.session_state.get(f"hw_{section_name}", False),
            key=f"cb_hw_{section_name}",
            help="Bumps sub rate from $3.00 to $3.25/sqft"
        )
        st.session_state[f"hw_{section_name}"] = hw
    with flag_cols[1]:
        ext = st.checkbox(
            "🌤 Exterior Install",
            value=st.session_state.get(f"ext_{section_name}", False),
            key=f"cb_ext_{section_name}",
        )
        st.session_state[f"ext_{section_name}"] = ext
    with flag_cols[2]:
        rem = st.checkbox(
            "🔧 Film Removal",
            value=st.session_state.get(f"rem_{section_name}", False),
            key=f"cb_rem_{section_name}",
            help=f"Adds ${REMOVAL_RATE_PER_SQFT:.2f}/sqft removal cost"
        )
        st.session_state[f"rem_{section_name}"] = rem

    # ── Section numbers ────────────────────────────────────────────────────
    info_col, cost_col = st.columns([2, 1])

    with info_col:
        film_display = ", ".join(res["film_names"])
        rate = best["rates"]
        rate_display = f"${rate['btf_base']:.2f}/LF base + ${rate['btf_fee']:.2f}/LF fee"
        order_method_label = "By the Foot" if best["order_method"] == "by_the_foot" else "Full 100 LF Roll"

        st.markdown(f"**Film:** {film_display}")
        st.markdown(f"**Best Roll Width:** {best['roll']}\" | **Dealer Rate:** {rate_display}")
        st.markdown(f"**Required:** {best['required_lf']} LF + {buffer_lf} LF buffer")
        st.markdown(f"**Order:** {best['order_lf']} LF ({order_method_label}) — **Material: ${best['mat_cost']:.2f}**")

        if crew_type == "sub":
            rate_label = f"${res['sub_rate']:.2f}/sqft"
            if res["is_high_work"]:
                rate_label += " (HIGH WORK)"
            if res["is_exterior"]:
                rate_label += " (EXTERIOR)"
            st.markdown(
                f"**Sub Labor:** {res['section_sqft']} sqft × {rate_label} = **${res['section_labor']:.2f}**"
            )

        if res["removal_cost"] > 0:
            st.markdown(
                f"**Film Removal:** {res['section_sqft']} sqft × ${REMOVAL_RATE_PER_SQFT:.2f}/sqft = **${res['removal_cost']:.2f}**"
            )

        if best.get("full_roll_savings"):
            st.success(f"💡 Full roll saves ${best['full_roll_savings']:.2f} vs. by-the-foot on this section.")

    with cost_col:
        section_total_cost = best["mat_cost"] + res["section_labor"] + res["removal_cost"]
        section_quote = build_quote(
            material_cost  = best["mat_cost"],
            labor_cost     = res["section_labor"],
            removal_cost   = res["removal_cost"],
            total_sqft     = res["section_sqft"],
            crew_type      = crew_type,
        )
        st.metric("Section Walk-Away",    f"${section_quote['walk_away']:,.2f}")
        st.metric("Section Recommended",  f"${section_quote['recommended']:,.2f}",
                  help=f"Rule: {section_quote['winning_label']}")
        st.caption(f"Material: ${best['mat_cost']:.2f} · Labor: ${res['section_labor']:.2f}")

    # ── Roll comparison ────────────────────────────────────────────────────
    with st.expander(f"Roll width comparison — {section_name}"):
        for item in res["comparison"]:
            marker = " ✅ best" if item["roll"] == best["roll"] else ""
            method = "by-the-foot" if item["order_method"] == "by_the_foot" else "full roll"
            savings_note = f" | saves ${item['full_roll_savings']:.2f} vs BTF" if item.get("full_roll_savings") else ""
            st.write(
                f"{item['roll']}\" roll | Required: {item['required_lf']} LF | "
                f"Order: {item['order_lf']} LF ({method}) | "
                f"Cost: ${item['mat_cost']:.2f}{savings_note}{marker}"
            )

    # ── Pull rows ──────────────────────────────────────────────────────────
    with st.expander(f"Cut sheet — {section_name}"):
        for idx, row in enumerate(best["rows"], start=1):
            pane_text = " + ".join([f"{p['width']}×{p['height']}" for p in row["panes"]])
            st.write(
                f"Row {idx}: {pane_text} | "
                f"Used Width: {row['used_width']}\" | "
                f"Pull to: {row['pull_to']}\" | "
                f"Lanes: {row['lanes']}"
            )

    order_lines.append(
        f"{', '.join(res['film_names'])} — {best['roll']}\" × {best['order_lf']} LF ({order_method_label})"
    )
    st.divider()

# ─────────────────────────────────────────────────────────────────────────────
# Material Order Summary
# ─────────────────────────────────────────────────────────────────────────────
if order_lines:
    st.subheader("🛒 Material Order Summary")
    for line in order_lines:
        st.markdown(f"- {line}")
    st.caption(f"Total material cost: ${total_mat_cost:,.2f}")
