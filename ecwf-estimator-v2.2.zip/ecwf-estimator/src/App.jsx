import { useState, useCallback, useMemo } from 'react';
import { FILM_DB, FILM_NAMES, ROLL_LENGTHS } from './data.js';
import {
  runTetris, calcMatCost, calcOrderOptions,
  calcSubLaborCost, calcDays, buildPrice,
  checkOverride, parseTintWiz, REMOVAL_RATE,
} from './engine.js';

// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
const C = {
  bg:'#070f1a', panel:'#0d1f35', panel2:'#091628', border:'#1e3050', border2:'#2e4870',
  green:'#00e5a0', red:'#ff4455', blue:'#4db8ff', amber:'#ffb300',
  purple:'#a78bfa', dim:'#8899aa', dimmer:'#4a6080', text:'#e8f0fe',
};
const mono = "'Space Mono','Courier New',monospace";

// ─── TINY UI HELPERS ──────────────────────────────────────────────────────────
const Lbl = ({ t }) => (
  <div style={{ fontSize:10, color:C.dim, fontFamily:mono, letterSpacing:'0.08em',
    textTransform:'uppercase', marginBottom:3 }}>{t}</div>
);

const SecHead = ({ children, first, color }) => (
  <div style={{
    fontFamily:mono, fontSize:10, letterSpacing:'0.18em', textTransform:'uppercase',
    color: color || C.green, borderBottom:`1px solid ${C.border}`,
    paddingBottom:5, marginBottom:10, marginTop: first ? 0 : 18,
  }}>{children}</div>
);

const iStyle = {
  width:'100%', boxSizing:'border-box', background:'#060e1a',
  border:`1px solid ${C.border}`, borderRadius:4,
  color:C.text, fontFamily:mono, fontSize:12, padding:'7px 9px', outline:'none',
};

const Inp = ({ label, value, onChange, type='text', min, step, placeholder, disabled }) => (
  <div style={{ marginBottom:9 }}>
    {label && <Lbl t={label} />}
    <input type={type} value={value} onChange={e => onChange(e.target.value)}
      min={min} step={step} placeholder={placeholder} disabled={disabled}
      style={{ ...iStyle, opacity: disabled ? 0.5 : 1 }} />
  </div>
);

const Sel = ({ label, value, onChange, options }) => (
  <div style={{ marginBottom:9 }}>
    {label && <Lbl t={label} />}
    <select value={value} onChange={e => onChange(e.target.value)}
      style={{ ...iStyle }}>
      {options.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
  </div>
);

const Stat = ({ label, value, sub, color, large }) => (
  <div style={{ borderLeft:`3px solid ${color || C.green}`, paddingLeft:9, marginBottom:6 }}>
    <div style={{ fontSize:9, color:C.dim, fontFamily:mono, letterSpacing:'0.08em', textTransform:'uppercase' }}>{label}</div>
    <div style={{ fontSize: large ? 22 : 17, fontWeight:700, color:C.text, fontFamily:mono, lineHeight:1.2 }}>{value}</div>
    {sub && <div style={{ fontSize:9, color:C.dimmer }}>{sub}</div>}
  </div>
);

const Chip = ({ children, color, bg }) => (
  <span style={{
    background: bg || 'rgba(0,229,160,0.12)', color: color || C.green,
    fontFamily:mono, fontWeight:700, fontSize:9, padding:'3px 8px',
    borderRadius:3, letterSpacing:'0.1em', display:'inline-block',
  }}>{children}</span>
);

const Toggle = ({ label, checked, onChange, color }) => (
  <label style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer',
    fontFamily:mono, fontSize:11, color: checked ? (color || C.green) : C.dim,
    userSelect:'none', marginBottom:4 }}>
    <div onClick={onChange} style={{
      width:28, height:16, borderRadius:8, background: checked ? (color || C.green) : C.border2,
      position:'relative', transition:'background 0.15s', cursor:'pointer', flexShrink:0,
    }}>
      <div style={{
        position:'absolute', top:2, left: checked ? 14 : 2,
        width:12, height:12, borderRadius:6, background:'#fff',
        transition:'left 0.15s',
      }} />
    </div>
    {label}
  </label>
);

// ─── SUMMARY RIBBON ───────────────────────────────────────────────────────────
function SummaryRibbon({ project, totalSqft, matCost, laborCost, crewType, walkAway, recommended, override, overrideVal }) {
  const displayPrice = override && overrideVal > 0 ? overrideVal : recommended;
  const isLoss = override && overrideVal > 0 && overrideVal < walkAway;

  return (
    <div style={{
      background:`linear-gradient(135deg, #0a1e36 0%, #061422 100%)`,
      border:`1px solid ${C.border2}`, borderRadius:6,
      padding:'16px 20px', marginBottom:16,
    }}>
      {/* Project identity */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:14 }}>
        <div>
          <div style={{ fontSize:9, color:C.green, letterSpacing:'0.2em', marginBottom:3 }}>PROJECT</div>
          <div style={{ fontSize:16, fontWeight:700, color:C.text }}>{project || 'Unnamed Project'}</div>
          <div style={{ fontSize:10, color:C.dim, marginTop:2 }}>{totalSqft.toFixed(1)} sqft total</div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:9, color:isLoss ? C.red : C.green, letterSpacing:'0.15em', marginBottom:3 }}>
            {isLoss ? '⚠ BELOW WALK-AWAY' : 'RECOMMENDED SELL PRICE'}
          </div>
          <div style={{ fontSize:28, fontWeight:700, fontFamily:mono,
            color: isLoss ? C.red : C.green }}>
            ${displayPrice.toFixed(2)}
          </div>
          {override && overrideVal > 0 && !isLoss && (
            <div style={{ fontSize:9, color:C.amber }}>OVERRIDE ACTIVE</div>
          )}
        </div>
      </div>

      {/* Cost ribbon */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10 }}>
        <div style={{ background:'rgba(0,0,0,0.25)', borderRadius:4, padding:'8px 10px' }}>
          <div style={{ fontSize:9, color:C.dim, letterSpacing:'0.08em', marginBottom:3 }}>MATERIAL COST</div>
          <div style={{ fontSize:15, fontWeight:700, color:C.text }}>${matCost.toFixed(2)}</div>
        </div>
        <div style={{ background:'rgba(0,0,0,0.25)', borderRadius:4, padding:'8px 10px' }}>
          <div style={{ fontSize:9, color:C.dim, letterSpacing:'0.08em', marginBottom:3 }}>
            {crewType === 'owner' ? 'LABOR — OWNER' : 'LABOR — SUB'}
          </div>
          <div style={{ fontSize:15, fontWeight:700, color:C.text }}>${laborCost.toFixed(2)}</div>
        </div>
        <div style={{ background:'rgba(0,0,0,0.25)', borderRadius:4, padding:'8px 10px' }}>
          <div style={{ fontSize:9, color:C.dim, letterSpacing:'0.08em', marginBottom:3 }}>WALK-AWAY FLOOR</div>
          <div style={{ fontSize:15, fontWeight:700, color:C.amber }}>${walkAway.toFixed(2)}</div>
        </div>
        <div style={{ background: isLoss ? 'rgba(255,68,85,0.15)' : 'rgba(0,229,160,0.10)',
          borderRadius:4, padding:'8px 10px',
          border:`1px solid ${isLoss ? C.red : 'transparent'}` }}>
          <div style={{ fontSize:9, color:C.dim, letterSpacing:'0.08em', marginBottom:3 }}>TARGET PRICE</div>
          <div style={{ fontSize:15, fontWeight:700, color: isLoss ? C.red : C.green }}>
            ${recommended.toFixed(2)}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── ROOM CARD ────────────────────────────────────────────────────────────────
function RoomCard({ room, crewType, globalFilm, onUpdate }) {
  const film = room.film || globalFilm;
  const filmData = FILM_DB[film] || {};

  // Run Tetris for this room's panes
  const tetris = useMemo(() => {
    if (!room.active) return null;
    const validPanes = room.panes.filter(p => p.w > 0 && p.h > 0 && p.qty > 0);
    return runTetris(validPanes);
  }, [room.panes, room.active]);

  const sqftPrice = filmData.sqftPrice || 0;
  const matCostExact = tetris ? calcMatCost(tetris.winner.pullFt, tetris.winner.rw, sqftPrice) : 0;

  const { cost: subLabor, rate: subRate } = crewType === 'sub' && film
    ? calcSubLaborCost(room.sqft, film, room.highWork, room.isExterior)
    : { cost: 0, rate: 0 };

  const removalCost = room.hasRemoval ? room.sqft * REMOVAL_RATE : 0;
  const totalRoomCost = matCostExact + subLabor + removalCost;

  const toggle = (field) => onUpdate(room.id, { [field]: !room[field] });

  return (
    <div style={{
      background: room.active ? C.panel : '#060e1a',
      border:`1px solid ${room.active ? C.border : C.border}`,
      borderRadius:6, marginBottom:10, overflow:'hidden',
      opacity: room.active ? 1 : 0.5, transition:'opacity 0.2s',
    }}>
      {/* Room header */}
      <div style={{
        display:'flex', alignItems:'center', justifyContent:'space-between',
        padding:'10px 14px', borderBottom:`1px solid ${C.border}`,
        background: room.active ? 'rgba(0,229,160,0.04)' : 'transparent',
        cursor:'pointer',
      }} onClick={() => onUpdate(room.id, { active: !room.active })}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{
            width:16, height:16, borderRadius:3,
            background: room.active ? C.green : C.border2,
            border:`2px solid ${room.active ? C.green : C.border2}`,
            flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            {room.active && <span style={{ fontSize:10, color:'#001a10', fontWeight:700 }}>✓</span>}
          </div>
          <div>
            <div style={{ fontSize:13, fontWeight:700, color:C.text }}>{room.name}</div>
            <div style={{ fontSize:10, color:C.dim }}>
              {room.paneCount} panes · {room.sqft} sqft
              {room.filmRaw && <span style={{ color:C.blue }}> · {room.filmRaw}</span>}
            </div>
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          {room.active && tetris && (
            <>
              <div style={{ fontSize:10, color:C.dim }}>Mat cost</div>
              <div style={{ fontSize:14, fontWeight:700, color:C.text }}>${matCostExact.toFixed(2)}</div>
            </>
          )}
        </div>
      </div>

      {/* Room details — only when active */}
      {room.active && (
        <div style={{ padding:'12px 14px' }}>
          {/* Notes */}
          {room.notes && (
            <div style={{ background:'rgba(255,179,0,0.07)', border:`1px solid rgba(255,179,0,0.2)`,
              borderRadius:4, padding:'6px 10px', fontSize:10, color:C.amber, marginBottom:10 }}>
              📋 {room.notes}
            </div>
          )}

          {/* Flags row */}
          <div style={{ display:'flex', gap:16, flexWrap:'wrap', marginBottom:10 }}>
            <Toggle label="High Work / Lift (12–25 ft AFF)"
              checked={room.highWork} color={C.amber}
              onChange={() => toggle('highWork')} />
            <Toggle label="Exterior Install"
              checked={room.isExterior} color={C.blue}
              onChange={() => toggle('isExterior')} />
            <Toggle label="Film Removal"
              checked={room.hasRemoval} color={C.purple}
              onChange={() => toggle('hasRemoval')} />
          </div>

          {/* Pane dims editor */}
          <div style={{ marginBottom:10 }}>
            <div style={{ fontSize:9, color:C.dimmer, letterSpacing:'0.1em', marginBottom:6 }}>PANE DIMENSIONS (inches)</div>
            {room.panes.map((p, pi) => (
              <div key={pi} style={{ display:'flex', gap:5, marginBottom:4, alignItems:'center' }}>
                <input value={p.label || room.name} readOnly
                  style={{ ...iStyle, flex:3, padding:'5px 6px', fontSize:10, opacity:0.6 }} />
                {[['w','W"'],['h','H"'],['qty','QTY']].map(([f, lbl]) => (
                  <div key={f} style={{ flex:1 }}>
                    {pi === 0 && <div style={{ fontSize:9, color:C.dim, marginBottom:2 }}>{lbl}</div>}
                    <input type="number" min={1} value={p[f]}
                      onChange={e => {
                        const newPanes = room.panes.map((pp, ppi) =>
                          ppi !== pi ? pp : { ...pp, [f]: Number(e.target.value) }
                        );
                        onUpdate(room.id, { panes: newPanes });
                      }}
                      style={{ ...iStyle, padding:'5px 5px', fontSize:11 }} />
                  </div>
                ))}
              </div>
            ))}
          </div>

          {/* Tetris results for this room */}
          {tetris && (
            <div style={{ background:'#060e1a', border:`1px solid ${C.border}`,
              borderRadius:4, padding:'10px 12px', marginBottom:8 }}>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:8 }}>
                <Stat label="Roll Width"   value={`${tetris.winner.rw}"`}              color={C.blue} />
                <Stat label="Pull Length"  value={`${tetris.winner.pullFt.toFixed(2)} ft`} color={C.blue} />
                <Stat label="Mat Cost"     value={`$${matCostExact.toFixed(2)}`}       color={C.blue} />
                <Stat label="Waste"        value={`${tetris.winner.wastePct.toFixed(1)}%`}
                  color={tetris.winner.wastePct > 25 ? C.amber : C.green} />
              </div>

              {crewType === 'sub' && film && (
                <div style={{ fontSize:10, color:C.dim, marginTop:4 }}>
                  Sub labor: {room.sqft} sqft × ${subRate.toFixed(2)}/sqft
                  {room.highWork ? ' (HIGH WORK rate)' : ''}
                  {room.isExterior ? ' (EXTERIOR rate)' : ''}
                  = <span style={{ color:C.text, fontWeight:700 }}>${subLabor.toFixed(2)}</span>
                </div>
              )}
              {room.hasRemoval && (
                <div style={{ fontSize:10, color:C.purple, marginTop:3 }}>
                  Removal: {room.sqft} sqft × ${REMOVAL_RATE.toFixed(2)}/sqft =
                  <span style={{ fontWeight:700 }}> ${removalCost.toFixed(2)}</span>
                </div>
              )}

              {/* Roll comparison */}
              <div style={{ marginTop:8, borderTop:`1px solid ${C.border}`, paddingTop:8 }}>
                <div style={{ fontSize:9, color:C.dimmer, letterSpacing:'0.1em', marginBottom:4 }}>ROLL COMPARISON</div>
                <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:2, fontSize:9, color:C.dimmer, marginBottom:3 }}>
                  <span>ROLL</span><span>PULL</span><span>SQFT</span><span>WASTE</span>
                </div>
                {tetris.all.map((p, i) => (
                  <div key={i} style={{
                    display:'grid', gridTemplateColumns:'repeat(4,1fr)',
                    fontSize:10, padding:'3px 0',
                    color: p.rw === tetris.winner.rw ? C.green : C.dimmer,
                    fontWeight: p.rw === tetris.winner.rw ? 700 : 400,
                  }}>
                    <span>{p.rw}"</span>
                    <span>{p.pullFt.toFixed(2)} ft</span>
                    <span>{p.sqft.toFixed(1)} sqft</span>
                    <span>{p.wastePct.toFixed(1)}%{p.rw === tetris.winner.rw ? ' ←' : ''}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {!film && (
            <div style={{ fontSize:10, color:C.amber, marginTop:4 }}>
              ⚠ No film matched for this room — select a film below to calculate material cost.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [twText,    setTWText]   = useState('');
  const [project,   setProject]  = useState(null);
  const [rooms,     setRooms]    = useState([]);
  const [parseErr,  setParseErr] = useState('');

  const [globalFilm,  setGlobalFilm]  = useState('Ultra View 15');
  const [crewType,    setCrewType]    = useState('owner');
  const [overrideVal, setOverrideVal] = useState('');
  const [orderChoice, setOrderChoice] = useState('exact'); // 'exact' | 'roll'
  const [showPaste,   setShowPaste]   = useState(true);

  // ── Parse TintWiz ──
  const doParse = () => {
    setParseErr('');
    if (!twText.trim()) { setParseErr('Paste TintWiz text first.'); return; }
    const parsed = parseTintWiz(twText);
    if (!parsed.rooms.length) {
      setParseErr('Could not find room data. Make sure you copied the full worksheet text.');
      return;
    }
    setProject(parsed);
    setRooms(parsed.rooms);
    // Auto-set global film if all rooms matched the same film
    const films = [...new Set(parsed.rooms.map(r => r.film).filter(Boolean))];
    if (films.length === 1) setGlobalFilm(films[0]);
    setShowPaste(false);
    setOverrideVal('');
    setOrderChoice('exact');
  };

  // ── Room update (single source of truth — all re-calcs flow from here) ──
  const updateRoom = useCallback((id, updates) => {
    setRooms(prev => prev.map(r => r.id === id ? { ...r, ...updates } : r));
  }, []);

  // ── Aggregate calculations ──
  const calc = useMemo(() => {
    const activeRooms = rooms.filter(r => r.active);
    if (!activeRooms.length) return null;

    let totalMatCost  = 0;
    let totalSubLabor = 0;
    let totalRemoval  = 0;
    let totalSqft     = 0;

    for (const room of activeRooms) {
      const film      = room.film || globalFilm;
      const filmData  = FILM_DB[film] || {};
      const sqftPrice = filmData.sqftPrice || 0;

      const validPanes = room.panes.filter(p => p.w > 0 && p.h > 0 && p.qty > 0);
      const tetris     = runTetris(validPanes);

      if (tetris) {
        const matExact = calcMatCost(tetris.winner.pullFt, tetris.winner.rw, sqftPrice);
        // Order option: exact vs full roll
        const opts = calcOrderOptions(tetris.winner.pullFt, tetris.winner.rw, sqftPrice);
        totalMatCost += orderChoice === 'roll' ? opts.roll.cost : opts.exact.cost;
      }

      if (crewType === 'sub' && film) {
        const { cost } = calcSubLaborCost(room.sqft, film, room.highWork, room.isExterior);
        totalSubLabor += cost;
      }

      if (room.hasRemoval) totalRemoval += room.sqft * REMOVAL_RATE;
      totalSqft += room.sqft;
    }

    const days          = calcDays(totalSqft, crewType);
    const laborCost     = crewType === 'sub' ? totalSubLabor : 0;
    const pricing       = buildPrice({
      materialCost: totalMatCost,
      laborCost,
      removalCost:  totalRemoval,
      crewType,
      totalSqft,
      days,
    });

    const ovr = overrideVal !== '' && parseFloat(overrideVal) > 0
      ? checkOverride(parseFloat(overrideVal), pricing.walkAway,
          pricing.totalCost, days, pricing.pmFloor)
      : null;

    return {
      totalMatCost, totalSubLabor, totalRemoval, totalSqft,
      laborCost, days, pricing, ovr,
    };
  }, [rooms, globalFilm, crewType, orderChoice, overrideVal]);

  const activeRoomCount = rooms.filter(r => r.active).length;

  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight:'100vh', background:C.bg, color:C.text, fontFamily:mono, paddingBottom:60 }}>

      {/* ── Top Header ── */}
      <div style={{
        background:`linear-gradient(135deg, ${C.panel} 0%, #091628 100%)`,
        borderBottom:`1px solid ${C.border}`, padding:'14px 24px',
        display:'flex', alignItems:'center', justifyContent:'space-between',
      }}>
        <div>
          <div style={{ fontSize:9, letterSpacing:'0.3em', color:C.green, marginBottom:2 }}>EAST COAST WINDOW FILMS</div>
          <div style={{ fontSize:18, fontWeight:700, letterSpacing:'0.06em' }}>ECWF ESTIMATOR ENGINE</div>
          <div style={{ fontSize:9, color:C.dimmer, marginTop:2 }}>QUOTE BUILDER · TETRIS CUT PLAN · v2.2</div>
        </div>
        <div style={{ display:'flex', gap:8' }}>
          <button onClick={() => setShowPaste(p => !p)} style={{
            background:'transparent', border:`1px solid ${C.border}`, borderRadius:4,
            color:C.dim, fontFamily:mono, fontSize:10, padding:'6px 12px', cursor:'pointer',
          }}>{showPaste ? '▲ Hide Upload' : '▼ Load Worksheet'}</button>
          {project && (
            <button onClick={() => { setProject(null); setRooms([]); setShowPaste(true); setOverrideVal(''); }} style={{
              background:'transparent', border:`1px solid ${C.border}`, borderRadius:4,
              color:C.red, fontFamily:mono, fontSize:10, padding:'6px 12px', cursor:'pointer',
            }}>✕ Clear Job</button>
          )}
        </div>
      </div>

      <div style={{ maxWidth:1100, margin:'0 auto', padding:'18px 18px 0' }}>

        {/* ── TintWiz paste panel ── */}
        {showPaste && (
          <div style={{ background:C.panel, border:`1px solid ${C.border}`, borderRadius:6, padding:16, marginBottom:16 }}>
            <SecHead first>Load TintWiz Worksheet</SecHead>
            <div style={{ fontSize:10, color:C.dim, marginBottom:8, lineHeight:1.8 }}>
              In your TintWiz PDF: <b style={{ color:C.text }}>Select All → Copy → Paste below.</b><br/>
              The tool extracts: client info, rooms, pane counts, dimensions, film name, and notes (including high-work flags).<br/>
              <span style={{ color:C.amber }}>Pricing is never in the TintWiz PDF — this tool builds your price from costs up.</span>
            </div>
            <textarea value={twText} onChange={e => setTWText(e.target.value)}
              placeholder="Paste TintWiz worksheet text here..." rows={7}
              style={{
                width:'100%', boxSizing:'border-box', background:'#060e1a',
                border:`1px solid ${C.border}`, borderRadius:4, color:C.text,
                fontFamily:mono, fontSize:10, padding:10, resize:'vertical', marginBottom:10,
              }} />
            {parseErr && <div style={{ fontSize:10, color:C.red, marginBottom:8 }}>{parseErr}</div>}
            <button onClick={doParse} style={{
              background:C.green, color:'#001a10', border:'none', borderRadius:4,
              fontFamily:mono, fontWeight:700, fontSize:12,
              padding:'9px 20px', cursor:'pointer', letterSpacing:'0.08em',
            }}>▶  PARSE &amp; BUILD ESTIMATE</button>
          </div>
        )}

        {/* ── Global job settings ── */}
        {rooms.length > 0 && (
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12, marginBottom:16 }}>
            <Sel label="Crew Type"
              value={crewType} onChange={setCrewType}
              options={[
                { v:'owner', l:'Owner Install — $700/day floor' },
                { v:'sub',   l:'Sub-Contractor — $500/day PM floor' },
              ]} />
            <Sel label="Global Film (applies to rooms without a matched film)"
              value={globalFilm} onChange={setGlobalFilm}
              options={FILM_NAMES.map(n => ({ v:n, l:`${n}  ·  $${FILM_DB[n].sqftPrice}/sqft  (${FILM_DB[n].brand})` }))} />
            <div>
              <Lbl t="Material Order" />
              <div style={{ display:'flex', gap:6 }}>
                {['exact','roll'].map(k => (
                  <button key={k} onClick={() => setOrderChoice(k)} style={{
                    flex:1, padding:'7px 0', borderRadius:4, fontFamily:mono, fontSize:10,
                    cursor:'pointer', fontWeight: orderChoice === k ? 700 : 400,
                    background: orderChoice === k ? C.green : 'transparent',
                    color: orderChoice === k ? '#001a10' : C.dim,
                    border:`1px solid ${orderChoice === k ? C.green : C.border}`,
                  }}>{k === 'exact' ? 'Exact Cut' : 'Full Roll'}</button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── Summary Ribbon ── */}
        {calc && project && (
          <SummaryRibbon
            project={project.clientName + (project.projectName ? ` — ${project.projectName}` : '')}
            totalSqft={calc.totalSqft}
            matCost={calc.totalMatCost}
            laborCost={calc.laborCost}
            crewType={crewType}
            walkAway={calc.pricing.walkAway}
            recommended={calc.pricing.recommended}
            override={overrideVal !== ''}
            overrideVal={parseFloat(overrideVal) || 0}
          />
        )}

        {/* ── Main two-column layout ── */}
        {rooms.length > 0 && (
          <div style={{ display:'grid', gridTemplateColumns:'1fr 380px', gap:16, alignItems:'start' }}>

            {/* ── LEFT: Room cards ── */}
            <div>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
                <div style={{ fontSize:10, color:C.dim, letterSpacing:'0.1em' }}>
                  ROOMS — {activeRoomCount} of {rooms.length} ACTIVE
                </div>
                <div style={{ display:'flex', gap:6 }}>
                  <button onClick={() => setRooms(r => r.map(x => ({ ...x, active:true })))}
                    style={{ background:'transparent', border:`1px solid ${C.border}`, borderRadius:3,
                      color:C.dim, fontFamily:mono, fontSize:9, padding:'4px 8px', cursor:'pointer' }}>All On</button>
                  <button onClick={() => setRooms(r => r.map(x => ({ ...x, active:false })))}
                    style={{ background:'transparent', border:`1px solid ${C.border}`, borderRadius:3,
                      color:C.dim, fontFamily:mono, fontSize:9, padding:'4px 8px', cursor:'pointer' }}>All Off</button>
                </div>
              </div>
              {rooms.map(room => (
                <RoomCard key={room.id} room={room} crewType={crewType}
                  globalFilm={globalFilm} onUpdate={updateRoom} />
              ))}
            </div>

            {/* ── RIGHT: Price panel ── */}
            {calc && (
              <div style={{ position:'sticky', top:16 }}>

                {/* Price breakdown */}
                <div style={{ background:C.panel, border:`1px solid ${C.border}`, borderRadius:6, padding:16, marginBottom:12 }}>
                  <SecHead first>Quote Builder</SecHead>

                  {/* Winning rule badge */}
                  <div style={{ marginBottom:12 }}>
                    <div style={{ fontSize:9, color:C.dim, letterSpacing:'0.1em', marginBottom:5 }}>PRICE SET BY</div>
                    {calc.pricing.winningRule === 'sqft-floor'    && <Chip>$7.50/SQFT FLOOR</Chip>}
                    {calc.pricing.winningRule === 'min-ticket'    && <Chip>$1,200 MINIMUM TICKET</Chip>}
                    {calc.pricing.winningRule === 'margin-buffer' && <Chip>30% MARGIN BUFFER</Chip>}
                  </div>

                  {/* Three rules comparison */}
                  {[
                    ['A) Margin Buffer (×1.30)',  calc.pricing.ruleA, 'margin-buffer'],
                    ['B) Min Ticket ($1,200)',     calc.pricing.ruleB, 'min-ticket'],
                    ['C) SqFt Floor (×$7.50)',    calc.pricing.ruleC, 'sqft-floor'],
                  ].map(([label, val, key]) => (
                    <div key={key} style={{
                      display:'flex', justifyContent:'space-between', alignItems:'center',
                      fontSize:11, padding:'5px 8px', borderRadius:3, marginBottom:3,
                      background: calc.pricing.winningRule === key ? 'rgba(0,229,160,0.08)' : 'transparent',
                      border: `1px solid ${calc.pricing.winningRule === key ? C.green : 'transparent'}`,
                    }}>
                      <span style={{ color: calc.pricing.winningRule === key ? C.green : C.dim }}>{label}</span>
                      <span style={{ fontWeight: calc.pricing.winningRule === key ? 700 : 400,
                        color: calc.pricing.winningRule === key ? C.green : C.text }}>
                        ${val.toFixed(2)}
                        {calc.pricing.winningRule === key && <span style={{ color:C.green }}> ←</span>}
                      </span>
                    </div>
                  ))}

                  <div style={{ borderTop:`1px solid ${C.border}`, margin:'10px 0' }} />

                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:12 }}>
                    <Stat label="Walk-Away Floor" value={`$${calc.pricing.walkAway.toFixed(2)}`} color={C.amber}
                      sub={`${crewType === 'owner' ? '$700' : '$500'}/day × ${calc.days} days`} />
                    <Stat label="Recommended Price" value={`$${calc.pricing.recommended.toFixed(2)}`} color={C.green} />
                    <Stat label="Gross Profit" value={`$${calc.pricing.grossProfit.toFixed(2)}`} color={C.green} />
                    <Stat label="Margin %" value={`${calc.pricing.marginPct.toFixed(1)}%`} color={C.green} />
                    <Stat label="Profit / Day" value={`$${calc.pricing.profitPerDay.toFixed(2)}`}
                      color={calc.pricing.profitPerDay >= calc.pricing.pmFloor ? C.green : C.red}
                      sub={`floor: $${calc.pricing.pmFloor}/day`} />
                    <Stat label="Days on Site" value={`${calc.days}`} color={C.dimmer}
                      sub={`${crewType === 'owner' ? '250' : '400'} sqft/day`} />
                  </div>

                  {/* Override input */}
                  <div style={{ borderTop:`1px solid ${C.border}`, paddingTop:12 }}>
                    <SecHead>Negotiation Override</SecHead>
                    <Inp label="Enter Client's Offer / Your Override Price ($)"
                      value={overrideVal} onChange={setOverrideVal}
                      type="number" min={0} step={1} placeholder="e.g. 3800" />
                    {calc.ovr && (
                      <div style={{
                        background: calc.ovr.isLoss ? 'rgba(255,68,85,0.12)' : 'rgba(0,229,160,0.07)',
                        border:`1px solid ${calc.ovr.isLoss ? C.red : C.green}`,
                        borderRadius:4, padding:'10px 12px',
                      }}>
                        {calc.ovr.isLoss && (
                          <div style={{ fontSize:11, color:C.red, fontWeight:700, marginBottom:6 }}>
                            ⛔ BELOW WALK-AWAY — THIS IS A LOSS
                          </div>
                        )}
                        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6 }}>
                          <Stat label="Override Profit" value={`$${calc.ovr.gp.toFixed(2)}`}
                            color={calc.ovr.isLoss ? C.red : C.green} />
                          <Stat label="Override Margin" value={`${calc.ovr.marg.toFixed(1)}%`}
                            color={calc.ovr.isLoss ? C.red : C.green} />
                          <Stat label="Override P/Day" value={`$${calc.ovr.ppd.toFixed(2)}`}
                            color={calc.ovr.ppd >= calc.pricing.pmFloor ? C.green : C.red} />
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Cost audit trail */}
                <div style={{ background:C.panel, border:`1px solid ${C.border}`, borderRadius:6, padding:14 }}>
                  <SecHead first>Cost Audit Trail</SecHead>
                  {[
                    ['Material Cost',    `$${calc.totalMatCost.toFixed(2)}`],
                    [crewType === 'sub' ? 'Sub Labor Cost' : 'Owner Labor',
                      crewType === 'sub' ? `$${calc.totalSubLabor.toFixed(2)}` : '$0.00 (owner install)'],
                    calc.totalRemoval > 0 ? ['Film Removal', `$${calc.totalRemoval.toFixed(2)}`] : null,
                    ['Total Cost',       `$${calc.pricing.totalCost.toFixed(2)}`],
                    ['+ PM Floor',       `$${(calc.days * calc.pricing.pmFloor).toFixed(2)}  (${calc.days}d × $${calc.pricing.pmFloor})`],
                    ['= Walk-Away',      `$${calc.pricing.walkAway.toFixed(2)}`],
                    ['× 1.30 Buffer →  A', `$${calc.pricing.ruleA.toFixed(2)}`],
                    ['Min Ticket →  B',    `$${calc.pricing.ruleB.toFixed(2)}`],
                    ['Sqft Floor →  C',    `$${calc.pricing.ruleC.toFixed(2)}`],
                    ['= RECOMMENDED',    `$${calc.pricing.recommended.toFixed(2)}`],
                  ].filter(Boolean).map(([k, v]) => (
                    <div key={k} style={{
                      display:'flex', justifyContent:'space-between',
                      fontSize:10, padding:'4px 0', borderBottom:`1px solid ${C.border}`,
                      fontWeight: k.startsWith('=') ? 700 : 400,
                      color: k.startsWith('=') ? C.green : k === '= Walk-Away' ? C.amber : C.text,
                    }}>
                      <span style={{ color: k.startsWith('=') ? 'inherit' : C.dim }}>{k}</span>
                      <span>{v}</span>
                    </div>
                  ))}
                </div>

              </div>
            )}
          </div>
        )}

        {/* ── Empty state ── */}
        {!rooms.length && !showPaste && (
          <div style={{ textAlign:'center', padding:'60px 0', color:C.border2 }}>
            <div style={{ fontSize:36, marginBottom:12 }}>◻</div>
            <div style={{ fontSize:11 }}>Load a TintWiz worksheet to begin</div>
          </div>
        )}

      </div>
    </div>
  );
}
