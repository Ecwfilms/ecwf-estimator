// ─── FILM DATABASE ────────────────────────────────────────────────────────────
// sqftPrice = your dealer cost per sqft (60" roll basis)
// subCategory = maps to sub-contractor rate table
// milThickness = used for security film sub-rate tiering

export const FILM_DB = {
  // ASWF Exclusive
  "Aurora 40":               { brand:"ASWF", series:"Exclusive",       sqftPrice:3.00, subCategory:"solar" },
  "Aurora 70":               { brand:"ASWF", series:"Exclusive",       sqftPrice:3.00, subCategory:"solar" },
  "Twilight 10":             { brand:"ASWF", series:"Exclusive",       sqftPrice:2.00, subCategory:"solar" },
  "Twilight 20":             { brand:"ASWF", series:"Exclusive",       sqftPrice:2.00, subCategory:"solar" },
  "Twilight 35":             { brand:"ASWF", series:"Exclusive",       sqftPrice:2.00, subCategory:"solar" },
  // ASWF Dual Reflective
  "Illusion":                { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  "Daydream 5":              { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  "Daydream 15":             { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  "Daydream 25":             { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  "Daydream 35":             { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  "Sky 10":                  { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  "Sky 20":                  { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  "Sky 30":                  { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  "Sky 40":                  { brand:"ASWF", series:"Dual Reflective", sqftPrice:1.19, subCategory:"solar" },
  // ASWF Solar
  "Legacy 40":               { brand:"ASWF", series:"Solar",           sqftPrice:1.58, subCategory:"solar" },
  "Legacy 50":               { brand:"ASWF", series:"Solar",           sqftPrice:1.58, subCategory:"solar" },
  "Legacy 70":               { brand:"ASWF", series:"Solar",           sqftPrice:1.58, subCategory:"solar" },
  "Nature 10":               { brand:"ASWF", series:"Solar",           sqftPrice:1.10, subCategory:"solar" },
  "Nature 20":               { brand:"ASWF", series:"Solar",           sqftPrice:1.10, subCategory:"solar" },
  "Nature 30":               { brand:"ASWF", series:"Solar",           sqftPrice:1.10, subCategory:"solar" },
  "Nature 40":               { brand:"ASWF", series:"Solar",           sqftPrice:1.10, subCategory:"solar" },
  "Nature 50":               { brand:"ASWF", series:"Solar",           sqftPrice:1.10, subCategory:"solar" },
  "Horizon 20":              { brand:"ASWF", series:"Solar",           sqftPrice:1.10, subCategory:"solar" },
  "Horizon 35":              { brand:"ASWF", series:"Solar",           sqftPrice:1.10, subCategory:"solar" },
  "Moonlight 05":            { brand:"ASWF", series:"Solar",           sqftPrice:1.24, subCategory:"solar" },
  "Moonlight 10":            { brand:"ASWF", series:"Solar",           sqftPrice:1.24, subCategory:"solar" },
  "Moonlight 25":            { brand:"ASWF", series:"Solar",           sqftPrice:1.24, subCategory:"solar" },
  "Reflection 20":           { brand:"ASWF", series:"Solar",           sqftPrice:0.86, subCategory:"solar" },
  "Reflection 35":           { brand:"ASWF", series:"Solar",           sqftPrice:0.86, subCategory:"solar" },
  "Reflection 50":           { brand:"ASWF", series:"Solar",           sqftPrice:0.86, subCategory:"solar" },
  "Firewall 70":             { brand:"ASWF", series:"Solar",           sqftPrice:1.58, subCategory:"solar" },
  // ASWF Design (Decorative)
  "UV Clear":                { brand:"ASWF", series:"Design",          sqftPrice:1.11, subCategory:"decorative" },
  "White Frost":             { brand:"ASWF", series:"Design",          sqftPrice:0.86, subCategory:"decorative" },
  "Black Out":               { brand:"ASWF", series:"Design",          sqftPrice:0.86, subCategory:"decorative" },
  "White Out":               { brand:"ASWF", series:"Design",          sqftPrice:0.86, subCategory:"decorative" },
  "Removable White Frost":   { brand:"ASWF", series:"Design",          sqftPrice:0.86, subCategory:"decorative" },
  "Removable Blackout":      { brand:"ASWF", series:"Design",          sqftPrice:0.86, subCategory:"decorative" },
  // ASWF Safety / Security
  "Safety 4 Mil":            { brand:"ASWF", series:"Safety",          sqftPrice:0.86, subCategory:"security", milThickness:4 },
  "Safety 7 Mil":            { brand:"ASWF", series:"Safety",          sqftPrice:1.10, subCategory:"security", milThickness:7 },
  "Safety 8 Mil":            { brand:"ASWF", series:"Safety",          sqftPrice:1.45, subCategory:"security", milThickness:8 },
  "Safety 12 Mil":           { brand:"ASWF", series:"Safety",          sqftPrice:2.65, subCategory:"security", milThickness:12 },
  "Safety 16 Mil":           { brand:"ASWF", series:"Safety",          sqftPrice:2.75, subCategory:"security", milThickness:16 },
  // Edge Architectural
  "Ultra View 5":            { brand:"Edge", series:"Architectural",   sqftPrice:0.84, subCategory:"solar" },
  "Ultra View 15":           { brand:"Edge", series:"Architectural",   sqftPrice:0.84, subCategory:"solar" },
  "Ultra View 25":           { brand:"Edge", series:"Architectural",   sqftPrice:0.84, subCategory:"solar" },
  "Ultra View 35":           { brand:"Edge", series:"Architectural",   sqftPrice:0.84, subCategory:"solar" },
  "Cool Alloy 20":           { brand:"Edge", series:"Architectural",   sqftPrice:1.15, subCategory:"solar" },
  "Cool Alloy 35":           { brand:"Edge", series:"Architectural",   sqftPrice:1.15, subCategory:"solar" },
  "Cool Alloy 60":           { brand:"Edge", series:"Architectural",   sqftPrice:1.15, subCategory:"solar" },
  "Silver 20":               { brand:"Edge", series:"Architectural",   sqftPrice:0.66, subCategory:"solar" },
  "Silver 30":               { brand:"Edge", series:"Architectural",   sqftPrice:0.66, subCategory:"solar" },
  "Silver 40":               { brand:"Edge", series:"Architectural",   sqftPrice:0.66, subCategory:"solar" },
  "Bronze 20":               { brand:"Edge", series:"Architectural",   sqftPrice:1.16, subCategory:"solar" },
  "Bronze 35":               { brand:"Edge", series:"Architectural",   sqftPrice:1.16, subCategory:"solar" },
  "Pristine Ceramic 30":     { brand:"Edge", series:"Architectural",   sqftPrice:1.86, subCategory:"solar" },
  "Pristine Ceramic 40":     { brand:"Edge", series:"Architectural",   sqftPrice:1.86, subCategory:"solar" },
  "Pristine Ceramic 50":     { brand:"Edge", series:"Architectural",   sqftPrice:1.86, subCategory:"solar" },
  "Pristine Ceramic 70":     { brand:"Edge", series:"Architectural",   sqftPrice:2.14, subCategory:"solar" },
  "Pristine Ceramic 80":     { brand:"Edge", series:"Architectural",   sqftPrice:2.14, subCategory:"solar" },
  // Huper Optik
  "Select SECH":             { brand:"Huper Optik", series:"Select",      sqftPrice:5.20, subCategory:"solar" },
  "Select DREI":             { brand:"Huper Optik", series:"Select",      sqftPrice:6.31, subCategory:"solar" },
  "KLAR 85":                 { brand:"Huper Optik", series:"Ceramic",     sqftPrice:4.53, subCategory:"solar" },
  "Ceramic 70":              { brand:"Huper Optik", series:"Ceramic",     sqftPrice:6.64, subCategory:"solar" },
  "Multi-Layer Ceramic 30":  { brand:"Huper Optik", series:"Ceramic",     sqftPrice:3.09, subCategory:"solar" },
  "Multi-Layer Ceramic 40":  { brand:"Huper Optik", series:"Ceramic",     sqftPrice:3.09, subCategory:"solar" },
  "Ceramic 50":              { brand:"Huper Optik", series:"Ceramic",     sqftPrice:2.14, subCategory:"solar" },
  "Ceramic 60":              { brand:"Huper Optik", series:"Ceramic",     sqftPrice:2.14, subCategory:"solar" },
  "Single Layer Ceramic 35": { brand:"Huper Optik", series:"Ceramic",     sqftPrice:1.61, subCategory:"solar" },
  "Single Layer Ceramic 45": { brand:"Huper Optik", series:"Ceramic",     sqftPrice:1.61, subCategory:"solar" },
  "Fusion 10":               { brand:"Huper Optik", series:"Traditional", sqftPrice:1.13, subCategory:"solar" },
  "Fusion 20":               { brand:"Huper Optik", series:"Traditional", sqftPrice:1.13, subCategory:"solar" },
  "Fusion 28":               { brand:"Huper Optik", series:"Traditional", sqftPrice:1.13, subCategory:"solar" },
  "Traditional Bronze 25":   { brand:"Huper Optik", series:"Traditional", sqftPrice:1.43, subCategory:"solar" },
  "Traditional Bronze 40":   { brand:"Huper Optik", series:"Traditional", sqftPrice:1.43, subCategory:"solar" },
  "Traditional Silver 18":   { brand:"Huper Optik", series:"Traditional", sqftPrice:0.99, subCategory:"solar" },
  "Traditional Silver 30":   { brand:"Huper Optik", series:"Traditional", sqftPrice:0.99, subCategory:"solar" },
};

export const FILM_NAMES = Object.keys(FILM_DB).sort();

// ─── SUB-CONTRACTOR RATE TABLE ────────────────────────────────────────────────
// Rates per sqft unless noted. AFF = Above Finished Floor.
export const SUB_RATES = {
  solar: {
    standard: 3.00,   // up to 12 ft AFF
    highWork:  3.25,  // 12–25 ft AFF
  },
  exterior: {
    standard: 3.00,
    highWork:  3.25,
  },
  decorative: {
    standard: 3.00,   // frosts, gradients — bump manually for custom patterns
    highWork:  3.00,  // decorative doesn't change with height
  },
  security: {
    // tiered by mil thickness
    getRate: (mil, highWork) => {
      let base;
      if (mil <= 8)       base = 3.00;
      else if (mil <= 11) base = 3.25;
      else if (mil <= 15) base = 3.50;
      else                base = 4.00; // 23mil Armored One / Signals Defense
      return highWork ? base + 0.25 : base;
    }
  },
};

// ─── STANDARD ROLL LENGTHS ────────────────────────────────────────────────────
export const ROLL_LENGTHS = [25, 50, 75, 100]; // feet

// ─── HIGH WORK KEYWORD DETECTION ─────────────────────────────────────────────
// Scans TintWiz notes for these keywords to auto-check the High Work flag
export const HIGH_WORK_KEYWORDS = [
  'lift', 'ladder', 'scaffold', 'aff', 'above', 'high work',
  'exterior', '12 ft', '12ft', 'elevated', 'boom', 'scissor'
];

export function detectHighWork(notesText) {
  if (!notesText) return false;
  const lower = notesText.toLowerCase();
  return HIGH_WORK_KEYWORDS.some(kw => lower.includes(kw));
}

// ─── FILM NAME FUZZY MATCHER ──────────────────────────────────────────────────
// Tries to match a raw film name from TintWiz to our FILM_DB keys
export function matchFilmName(raw) {
  if (!raw) return null;
  const clean = raw.toLowerCase().replace(/\s+/g, ' ').trim();

  // Direct match first
  const direct = FILM_NAMES.find(n => n.toLowerCase() === clean);
  if (direct) return direct;

  // Partial match — score by how many words overlap
  let best = null, bestScore = 0;
  for (const name of FILM_NAMES) {
    const nameLower = name.toLowerCase();
    const score = clean.split(' ').filter(w => w.length > 1 && nameLower.includes(w)).length;
    if (score > bestScore) { bestScore = score; best = name; }
  }
  return bestScore >= 1 ? best : null;
}
